﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmNotice : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm,cm1;
    SqlDataReader dr,dr1;
    DataTable dt,dt1;
    int i, j, n, c, n1;
    protected void Page_Load(object sender, EventArgs e)
    {
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Notice", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void seeRecord()
    {
        try
        {
            txtNoticeid.Text = dt.Rows[c].ItemArray[0].ToString();
            ddlMeetingId.Text = dt.Rows[c].ItemArray[1].ToString();
            txtAgenda.Text = dt.Rows[c].ItemArray[2].ToString();
            ddlMDate.Text = dt.Rows[c].ItemArray[3].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record Found...');</script>"); }
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        select();
    }
    protected void enable()
    {
        txtNoticeid.Enabled = true;
        txtAgenda.Enabled = true;
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(Noticeid) from Notice", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtNoticeid.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtNoticeid.Text = "1";
            dr.Close();
        }
    }
    protected void select()
    {
        ddlMeetingId.Items.Clear();
        ddlMDate.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select * from Meeting", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlMeetingId.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
            ddlMDate.Items.Add(dt1.Rows[i].ItemArray[1].ToString());
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        c = 0;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record !..');</script>");
        }
    
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
   protected void clr()
   {
       txtNoticeid.Text="";
       txtAgenda.Text="";
   }
   protected void btnSend_Click(object sender, EventArgs e)
   {
       try
       {
               cm = new SqlCommand("insert into Notice values(" + int.Parse(txtNoticeid.Text) + "," + int.Parse(ddlMeetingId.SelectedItem.ToString()) + ",'" + txtAgenda.Text + "',@d1)", cn);
               cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(ddlMDate.SelectedItem.ToString()).ToShortDateString();
               int z = cm.ExecuteNonQuery();
               if (z == 1)
               {
                   Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                   clr();
               }
               
        }
       catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>"); }
   }
}