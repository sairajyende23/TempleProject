﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Outword : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm,cm1;
    SqlDataReader dr,dr1;
    DataTable dt,dt1,dt2;
    int c,n,n1,i,j;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        lblToday.Text = DateTime.Now.Date.ToShortDateString();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Outword", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>"); 
        }
    }
    protected void seeRecord()
    {
        lblToday.Text = dt.Rows[c].ItemArray[0].ToString();
        txtOutid.Text = dt.Rows[c].ItemArray[1].ToString();
        txtCustnm.Text = dt.Rows[c].ItemArray[2].ToString();
        ddlProduct.Text = dt.Rows[c].ItemArray[3].ToString();
        txtCon.Text = dt.Rows[c].ItemArray[4].ToString();
        txtAmt.Text=dt.Rows[c].ItemArray[5].ToString();
        ddlRby.Text = dt.Rows[c].ItemArray[6].ToString();
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        select();
    }
    protected void enable()
    {
        btnSearch.Enabled = true;
        txtOutid.Enabled = true;
        txtCustnm.Enabled = true;
        txtCon.Enabled = true;
        txtAmt.Enabled = true;
        btnAdd.Enabled = true;
        btnClear.Enabled = true;
        btnDelete.Enabled = true;
        btnUpdate.Enabled = true;
        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;
    }
    protected void select()
    {
        ddlProduct.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select ProductNm from Inword", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlProduct.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
        }
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(OutwordId) from Outword", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtOutid.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtOutid.Text = "1";
            dr.Close();
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();

        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Further Record..');</script>"); 
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"].ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Previous Record..');</script>"); 
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"]=c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("insert into Outword values(@d1,"+int.Parse(txtOutid.Text)+",'"+txtCustnm.Text+"','"+ddlProduct.SelectedItem+"','"+Int64.Parse(txtCon.Text)+"','"+Int64.Parse(txtAmt.Text)+"','"+ddlRby.SelectedItem+"')",cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
            }
            clr();
        }
        catch(Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Inserted successfully !..');</script>");
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update Outword set OutwordDate=@d1,CustNm='"+txtCustnm.Text+"',ProductNm='"+ddlProduct.SelectedItem+"',ContactNo='"+Int64.Parse(txtCon.Text)+"',Amount='"+Int64.Parse(txtAmt.Text)+"',ReceivedBy='"+ddlRby.SelectedItem+"' where OutwordId="+int.Parse(txtOutid.Text)+"", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated Successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Updated Successfully !..');</script>");
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from Outword where OutwordId="+int.Parse(txtOutid.Text)+"",cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted Successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Deleted Successfully !..');</script>");
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtOutid.Text = "";
        txtCustnm.Text = "";
        txtCon.Text = "";
        txtAmt.Text = "";
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt2.Clear();
            cm = new SqlCommand("select * from Outword where OutwordId like( '" + int.Parse(txtOutid.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt2.Load(dr);
            dr.Close();
            lblToday.Text = dt2.Rows[0].ItemArray[0].ToString();
            txtOutid.Text = dt2.Rows[0].ItemArray[1].ToString();
            txtCustnm.Text = dt2.Rows[0].ItemArray[2].ToString();
            ddlProduct.Text = dt2.Rows[0].ItemArray[3].ToString();
            txtCon.Text = dt2.Rows[0].ItemArray[4].ToString();
            txtAmt.Text = dt2.Rows[0].ItemArray[5].ToString();
            ddlRby.Text = dt2.Rows[0].ItemArray[6].ToString();
        }
        catch (Exception ee) { clr(); }
    }
}