﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmElection : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm,cm1;
    SqlDataReader dr,dr1,dr2;
    DataTable dt,dt1,dt2,dt3;
    int c, i, j, n, n1,n2;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        dt3 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Election", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void seeRecord()
    {
        try
        {
            txtEid.Text = dt.Rows[c].ItemArray[0].ToString();
            txtEDate.Text = dt.Rows[c].ItemArray[1].ToString();
            txtYear.Text = dt.Rows[c].ItemArray[2].ToString();
            ddlPost.Text = dt.Rows[c].ItemArray[3].ToString();
            ddlWinner.Text = dt.Rows[c].ItemArray[4].ToString();
            ddlLoser.Text = dt.Rows[c].ItemArray[5].ToString();
            txtVInfwin.Text = dt.Rows[c].ItemArray[6].ToString();
            txtVInfLo.Text = dt.Rows[c].ItemArray[7].ToString();
            txtvAgainstwin.Text = dt.Rows[c].ItemArray[8].ToString();
            txtvAgainstLoser.Text = dt.Rows[c].ItemArray[9].ToString();
            txtRejvWin.Text = dt.Rows[c].ItemArray[10].ToString();
            txtRejvLoser.Text = dt.Rows[c].ItemArray[11].ToString();
            txtTotVWiner.Text = dt.Rows[c].ItemArray[12].ToString();
            txtTotVLooser.Text = dt.Rows[c].ItemArray[13].ToString();
            ddlcby.Text = dt.Rows[c].ItemArray[14].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Further Record !..');</script>"); }
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        select1();
        select2();
    }
    private void enable()
    {
        btnSearch.Enabled = true;
        txtEDate.Enabled = true;
        txtEid.Enabled = true;
        txtRejvLoser.Enabled = true;
        txtRejvWin.Enabled = true;
        txtTotVLooser.Enabled = true;
        txtTotVWiner.Enabled = true;
        txtvAgainstLoser.Enabled = true;
        txtvAgainstwin.Enabled = true;
        txtVInfLo.Enabled = true;
        txtVInfwin.Enabled = true;
        txtYear.Enabled = true;
        btnAdd.Enabled = true;
        btnClear.Enabled = true;
        btnDelete.Enabled = true;
        btnUpdate.Enabled = true;
        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;
    }
    private void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(ElectionId) from Election", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtEid.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtEid.Text = "1";
            dr.Close();
        }
    }
    protected void select1()
    {
        ddlWinner.Items.Clear();
        ddlLoser.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select * from CommityMember", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlWinner.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlLoser.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
        }       
    }
    protected void select2()
    {
        ddlPost.Items.Clear();
        dt2.Clear();
        cm1 = new SqlCommand("select DName from Designation", cn);
        dr2 = cm1.ExecuteReader();
        dt2.Load(dr2);
        dr2.Close();
        n2 = dt2.Rows.Count - 1;
        for (i = 0; i <= n2; i++)
        {
            ddlPost.Items.Add(dt2.Rows[i].ItemArray[0].ToString());
        }

    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        c = 0;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
                cm = new SqlCommand("insert into Election values(" + int.Parse(txtEid.Text) + ",@d1,'" + txtYear.Text + "','" + ddlPost.SelectedItem + "','" + ddlWinner.SelectedItem + "','" + ddlLoser.SelectedItem + "','" + Int64.Parse(txtVInfwin.Text) + "','" + Int64.Parse(txtVInfLo.Text) + "','" + Int64.Parse(txtvAgainstwin.Text) + "','" + Int64.Parse(txtvAgainstLoser.Text) + "','" + Int64.Parse(txtRejvWin.Text) + "','" + Int64.Parse(txtRejvLoser.Text) + "','" + Int64.Parse(txtTotVWiner.Text) + "','" + Int64.Parse(txtTotVLooser.Text) + "','" + ddlcby.SelectedItem + "')", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtEDate.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record inserted successfully..');</script>");
                    clr();
                }
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Inserted Successfully..');</script>"); 
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update Election set EDate=@d1,AYear='" + txtYear.Text + "',Post='" + ddlPost.SelectedItem + "',Winner='" + ddlWinner.SelectedItem + "',Looser='" + ddlLoser.SelectedItem + "',WVInFavour='" + Int64.Parse(txtVInfwin.Text) + "',LVInFavour='" + Int64.Parse(txtVInfLo.Text) + "',WVInAgainst='" + Int64.Parse(txtvAgainstwin.Text) + "',LVInAgainst='" + Int64.Parse(txtvAgainstLoser.Text) + "',WRegistedVotes='" + Int64.Parse(txtRejvWin.Text) + "',LRegistedVotes='" + Int64.Parse(txtRejvLoser.Text) + "',WTotVotes='" + Int64.Parse(txtTotVWiner.Text) + "',LTotVotes='" + Int64.Parse(txtTotVLooser.Text) + "',CheckedBy='" + ddlcby.SelectedItem + "' where ElectionId=" + int.Parse(txtEid.Text) + "", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtEDate.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully !..');</script>"); 
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from Election where ElectionId=" + int.Parse(txtEid.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
                clr();
            }
           
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtEDate.Text = "";
        txtEid.Text = "";
        txtRejvLoser.Text = "";
        txtRejvWin.Text = "";
        txtTotVLooser.Text = "";
        txtTotVWiner.Text = "";
        txtvAgainstLoser.Text = "";
        txtvAgainstwin.Text = "";
        txtVInfLo.Text = "";
        txtVInfwin.Text = "";
        txtYear.Text = "";
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtEDate.Text = @Calendar1.SelectedDate.Date.ToShortDateString();
    }
    protected void ddlPost_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }

    protected void ImgCalender_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible == false)
        {
            Calendar1.Visible = true;
        }
        else if (Calendar1.Visible == true)
        {
            Calendar1.Visible = false;
        }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt3.Clear();
            cm = new SqlCommand("select * from Election where ElectionId like( '" + int.Parse(txtEid.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt3.Load(dr);
            dr.Close();
            txtEid.Text = dt3.Rows[0].ItemArray[0].ToString();
            txtEDate.Text = dt3.Rows[0].ItemArray[1].ToString();
            txtYear.Text = dt3.Rows[0].ItemArray[2].ToString();
            ddlPost.Text = dt3.Rows[0].ItemArray[3].ToString();
            ddlWinner.Text = dt3.Rows[0].ItemArray[4].ToString();
            ddlLoser.Text = dt3.Rows[0].ItemArray[5].ToString();
            txtVInfwin.Text = dt3.Rows[0].ItemArray[6].ToString();
            txtVInfLo.Text = dt3.Rows[0].ItemArray[7].ToString();
            txtvAgainstwin.Text = dt3.Rows[0].ItemArray[8].ToString();
            txtvAgainstLoser.Text = dt3.Rows[0].ItemArray[9].ToString();
            txtRejvWin.Text = dt3.Rows[0].ItemArray[10].ToString();
            txtRejvLoser.Text = dt3.Rows[0].ItemArray[11].ToString();
            txtTotVWiner.Text = dt3.Rows[0].ItemArray[12].ToString();
            txtTotVLooser.Text = dt3.Rows[0].ItemArray[13].ToString();
            ddlcby.Text = dt3.Rows[0].ItemArray[14].ToString();
        
        }
        catch (Exception ee) { clr(); }
    }
}