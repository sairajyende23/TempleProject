﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class UserRegistration : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("select * from Login where username='"+txtUName.Text+"'and password='"+txtPass.Text+"'",cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {               
                clr();
                Response.Write("<script type='text/javascript'>alert('Login Successfully done !...');</script>");
                Session["login"] = txtUName.Text;
                Response.Redirect("~/Index1.aspx");
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Login Unsuccessful !...');</script>");
            }
            dr.Close();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>"); }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtUName.Text = "";
        txtPass.Text = "";
    }
}