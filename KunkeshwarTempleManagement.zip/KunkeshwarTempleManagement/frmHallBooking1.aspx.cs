﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO.Ports;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.IO;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Net;

public partial class frmHallBooking1 : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt;
    int c, n, i, j;
    protected void Page_Load(object sender, EventArgs e)
    {
         //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        lblToday.Text = DateTime.Now.ToShortDateString();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from HallBooking",cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>"); }
    }
    protected void seeRecord()
    {
        txtNo.Text = dt.Rows[c].ItemArray[1].ToString();
        txtNm.Text = dt.Rows[c].ItemArray[2].ToString();
        txtCon.Text = dt.Rows[c].ItemArray[3].ToString();
        txtEvent.Text = dt.Rows[c].ItemArray[4].ToString();
        txtStart.Text = dt.Rows[c].ItemArray[5].ToString();
        txtEnd.Text = dt.Rows[c].ItemArray[6].ToString();
        txtAmt.Text = dt.Rows[c].ItemArray[7].ToString();
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        Bookdays();
        txtAmt.Text = "2000";
    }
    protected void enable()
    {
       // txtAmt.Enabled = true;
        txtCon.Enabled = true;
        txtEnd.Enabled = true;
        txtEvent.Enabled = true;
        txtNm.Enabled = true;

        txtNo.Enabled = true;
        txtStart.Enabled = true;
        btnAdd.Enabled = true;

        btnClear.Enabled = true;

        btnEAdd.Enabled = true;
        btnSAdd.Enabled = true;
        btnClick.Enabled = true;

    }
    protected void Bookdays()
    {
        try
        {
            for (i = 0; i <= n; i++)
            {
                DateTime start = Convert.ToDateTime(dt.Rows[i].ItemArray[5]);
                int v1 = start.Day;
                DateTime end = Convert.ToDateTime(dt.Rows[i].ItemArray[6]);
                int v2 = end.Day;
                int a = 1;
                Calendar1.SelectedDates.Add(Convert.ToDateTime(start));
                while (v1 < v2)
                {
                    DateTime d3 = start.AddDays(a);
                    Calendar1.SelectedDates.Add(Convert.ToDateTime(d3));
                    Calendar1.SelectedDayStyle.BackColor = System.Drawing.Color.DeepPink;
                    v1++;
                    a++;
                }
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(SrNo) from HallBooking", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtNo.Text = j.ToString();
            }
        }
        catch (Exception ee)
        {
            txtNo.Text = "1";
            dr.Close();
        }
    }

    protected void btnClick_Click(object sender, EventArgs e)
    {
        Calendar1.SelectedDates.Clear(); txtAmt.Text = "2000";
    }
    protected void btnSAdd_Click(object sender, EventArgs e)
    {
        txtStart.Text = @Calendar1.SelectedDate.Date.ToShortDateString(); txtAmt.Text = "2000";
    }
    protected void btnEAdd_Click(object sender, EventArgs e)
    {
        txtEnd.Text = @Calendar1.SelectedDate.Date.ToShortDateString(); txtAmt.Text = "2000";
    }
    protected void clr()
    {
        txtNo.Text = "";
        txtNm.Text = "";
        txtEvent.Text = "";
        txtAmt.Text = "";
        txtCon.Text = "";
        txtStart.Text = "";
        txtEnd.Text = "";
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {

    }
    protected void btnAdd_Click1(object sender, EventArgs e)
    {
        try
        {
                cm = new SqlCommand("insert into HallBooking values(@d1," + int.Parse(txtNo.Text) + ",'" + txtNm.Text + "','" + Int64.Parse(txtCon.Text) + "','" + txtEvent.Text + "',@d2,@d3,'" + Int64.Parse(txtAmt.Text) + "','" + txtNm.Text + "')", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtStart.Text).ToShortDateString();
                cm.Parameters.Add("@d3", SqlDbType.DateTime).Value = DateTime.Parse(txtEnd.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                    try
                    {
                        sendSMS(txtCon.Text);
                    }
                    catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Internet Connection For Sending SMS!..');</script>"); }
                    clr();
                    Calendar1.SelectedDates.Clear();
                }              
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert(" + ee.ToString() + ");</script>"); }
    }
    public string sendSMS(string no)
    {
        String result;
        string apiKey = "v+JmIgh3PtA-DdQu6ZfyxXAx9kZgqtkjvXHTIWCxIF";
        string numbers = "91" + no; // in a comma seperated list

        string message = "Hall Booking Is Done. Thank You!..";
        string sender = "TXTLCL";

        String url = "https://api.textlocal.in/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + sender;
        //refer to parameters to complete correct url string

        StreamWriter myWriter = null;
        HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

        objRequest.Method = "POST";
        objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
        objRequest.ContentType = "application/x-www-form-urlencoded";
        try
        {
            myWriter = new StreamWriter(objRequest.GetRequestStream());
            myWriter.Write(url);
        }
        catch (Exception e)
        {
            return e.Message;
        }
        finally
        {
            myWriter.Close();
        }

        HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
        using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
        {
            result = sr.ReadToEnd();
            // Close and clean up the StreamReader
            sr.Close();
        }
        return result;
    }  
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr(); txtAmt.Text = "2000";
    }
}