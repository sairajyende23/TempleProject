﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class AteendeeMasterDetails : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt;
    int c,n,i;
    protected void Page_Load(object sender, EventArgs e)
    {
        cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        txtMid.Text = Session["a"].ToString();
        txtMDate.Text = Session["b"].ToString();
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from AttendeeMaster", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void seeRecord()
    {
        try
        {
           txtMid.Text=dt.Rows[c].ItemArray[0].ToString();
           txtMDate.Text=dt.Rows[c].ItemArray[1].ToString();
           txtMemberNo.Text=dt.Rows[c].ItemArray[2].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record !..');</script>"); }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
            txtMid.Text = Session["a"].ToString();
            txtMDate.Text = Session["b"].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Further Record !..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
            txtMid.Text = Session["a"].ToString();
            txtMDate.Text = Session["b"].ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
            txtMid.Text = Session["a"].ToString();
            txtMDate.Text = Session["b"].ToString();    
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
        txtMid.Text = Session["a"].ToString();
        txtMDate.Text = Session["b"].ToString();   
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("insert into AttendeeMaster values(" + int.Parse(txtMid.Text) + ",@d1,'" + txtMemberNo.Text + "')", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtMDate.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Inserted successfully..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted Successfully..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from AttendeeMaster where MemberNo=" + int.Parse(txtMemberNo.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtMemberNo.Text = "";
    }
}