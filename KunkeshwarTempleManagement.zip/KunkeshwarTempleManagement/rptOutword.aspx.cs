﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class rptOutword : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm, cm1;
    SqlDataReader dr, dr1;
    DataTable dt, dt1;
    protected void Page_Load(object sender, EventArgs e)
    {
            cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename="+ Server.MapPath("~/App_Data/Temple.mdf")+";Integrated Security=True");   
            cn.Open();
            dt = new DataTable();
            dt1 = new DataTable();
        }
        private void showData()
        {
            dt.Clear();
            cm = new SqlCommand("select * from Outword", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();

            ddlOutwordId.DataSource = dt;
            ddlOutwordId.DataTextField = "OutwordId";
            ddlOutwordId.DataValueField = "OutwordId";
            ddlOutwordId.DataBind();
        }
    protected void ddlExpId_SelectedIndexChanged(object sender, EventArgs e)
{
        try
        {
            dt1.Clear();
            cm1 = new SqlCommand("select * from Outword where OutwordId=" + int.Parse(ddlOutwordId.SelectedItem.ToString()), cn);
            dr1 = cm1.ExecuteReader();
            dt1.Load(dr1);
            dr1.Close();

            ReportViewer1.LocalReport.DataSources.Clear();
            ReportViewer1.LocalReport.Refresh();
            ReportViewer1.LocalReport.DataSources.Add(new Microsoft.Reporting.WebForms.ReportDataSource("DataSet1", dt1));
            ReportViewer1.DataBind();
            ReportViewer1.LocalReport.Refresh();
        }
        catch (Exception dd)
        { Response.Write("<script type='text/javascript'>alert('Error Found in Report !..');</script>"); }
}
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/Index1.aspx");
    }
}
 