﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class EventMaster : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm,cm1;
    SqlDataReader dr,dr1;
    DataTable dt,dt1,dt2;
    int i,c,n,j,n1;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        allRecords();      
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    private void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Event", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    private void seeRecord()
    {
        try
        {
            txtEventid.Text = dt.Rows[c].ItemArray[0].ToString();
            ddlENm.Text = dt.Rows[c].ItemArray[1].ToString();
            txtStart.Text = dt.Rows[c].ItemArray[2].ToString();
            txtEnd.Text = dt.Rows[c].ItemArray[3].ToString();
            txtDuration.Text = dt.Rows[c].ItemArray[4].ToString();
            txtFee.Text = dt.Rows[c].ItemArray[5].ToString();
            txtAgeGroup.Text = dt.Rows[c].ItemArray[6].ToString();
            ddlcby.Text = dt.Rows[c].ItemArray[7].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No any Record !...');</script>"); }
    }
    protected void btnshowBID_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        select();
    }
    protected void enable()
    {
        btnSearch.Enabled = true;
        txtAgeGroup.Enabled = true;
        txtDuration.Enabled = true;
        txtEnd.Enabled = true;
        txtEventid.Enabled = true;
        txtFee.Enabled = true;
        txtStart.Enabled = true;
        btnAdd.Enabled = true;
        btnClear.Enabled = true;
        btnDelete.Enabled = true;      
        btnUpdate.Enabled = true;
        btnSAdd.Enabled = true;
        btnEAdd.Enabled = true;
        btnFst.Enabled = true;
        btnShow.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;

    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(EventId) from Event", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtEventid.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtEventid.Text = "1";
            dr.Close();
        }
    }
    private void select()
    {
        ddlENm.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select * from Activities",cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlENm.Items.Add(dt1.Rows[i].ItemArray[1].ToString());
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Further Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
                cm = new SqlCommand("insert into Event values(" + int.Parse(txtEventid.Text) + ",'" + ddlENm.SelectedItem + "',@d1,@d2,'" + txtDuration.Text + "','" + txtFee.Text + "','" + txtAgeGroup.Text + "','" + ddlcby.SelectedItem + "')", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtStart.Text).ToShortDateString();
                cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtEnd.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                    clr();
                }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update Event set EventNm='" + ddlENm.SelectedItem + "',StartDate=@d1,EndDate=@d2,Duration='" + txtDuration.Text + "',EventFee='" + Int64.Parse(txtFee.Text) + "',Agegroup='"+txtAgeGroup.Text+"',CheckedBy='" +ddlcby.SelectedItem + "' where EventId=" + int.Parse(txtEventid.Text) + "", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtStart.Text).ToShortDateString();
            cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtEnd.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from Event where EventId=" + int.Parse(txtEventid.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Deleted successfully !..');</script>");
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtEventid.Text = "";
        txtStart.Text = "";
        txtEnd.Text = "";
        txtDuration.Text = "";
        txtAgeGroup.Text = "";
        txtFee.Text = "";
    }
    protected void btnSAdd_Click(object sender, EventArgs e)
    {
        txtStart.Text = @Calendar1.SelectedDate.Date.ToShortDateString();
    }
    protected void btnEAdd_Click(object sender, EventArgs e)
    {
        txtEnd.Text = @Calendar1.SelectedDate.Date.ToShortDateString();
    }
    protected void btnShow_Click(object sender, EventArgs e)
    {
        DateTime d1 = DateTime.Parse(txtStart.Text);
        DateTime d2 = DateTime.Parse(txtEnd.Text);
        TimeSpan t1 = d2 - d1;
        txtDuration.Text = ((t1.TotalDays)+1).ToString()+" Days";
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt2.Clear();
            cm = new SqlCommand("select * from Event where EventId like( '" + int.Parse(txtEventid.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt2.Load(dr);
            dr.Close();
            txtEventid.Text = dt2.Rows[0].ItemArray[0].ToString();
            ddlENm.Text = dt2.Rows[0].ItemArray[1].ToString();
            txtStart.Text = dt2.Rows[0].ItemArray[2].ToString();
            txtEnd.Text = dt2.Rows[0].ItemArray[3].ToString();
            txtDuration.Text = dt2.Rows[0].ItemArray[4].ToString();
            txtFee.Text = dt2.Rows[0].ItemArray[5].ToString();
            txtAgeGroup.Text = dt2.Rows[0].ItemArray[6].ToString();
            ddlcby.Text = dt2.Rows[0].ItemArray[7].ToString();
        }
        catch (Exception ee) { clr(); }
    }
}