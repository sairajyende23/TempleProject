﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO.Ports;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.IO;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Net;

public partial class meeting : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt,dt1;
    int j, n, c;
    protected void Page_Load(object sender, EventArgs e)
    {
        SerialPort sp = new SerialPort();
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        allRecords();
        lblToday.Text = DateTime.Now.ToShortDateString();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        if (Session["login"] == null)
        {
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            btnFst.Visible = false;
            btnNext.Visible = false;
            btnPre.Visible = false;
            btnLast.Visible = false;
        }
        if (rdbCheque.Checked == false)
        {
            txtCheque.Enabled = false;
        }
        else
        {
            txtCheque.Enabled = true;
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Donation", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch(Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>");
        }
    }
    protected void seeRecords()
    {
        lblToday.Text = dt.Rows[c].ItemArray[0].ToString();
        txtDId.Text = dt.Rows[c].ItemArray[1].ToString();
        txtDnm.Text = dt.Rows[c].ItemArray[2].ToString();
        txtAddrs.Text =dt.Rows[c].ItemArray[3].ToString();
        txtCon.Text = dt.Rows[c].ItemArray[4].ToString();
        string gen=dt.Rows[c].ItemArray[5].ToString();
        try
        {
            if (gen.Equals("male"))
            {
                rdbm.Checked = true; rdbf.Checked = false; rdbo.Checked = false;
            }
            else if (gen.Equals("female"))
            {
                rdbf.Checked = true; rdbm.Checked = false; rdbo.Checked = false;
            }
            else if (gen.Equals("other"))
            {
                rdbo.Checked = true; rdbm.Checked = false; rdbf.Checked = false;
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>");}
        txtEid.Text=dt.Rows[c].ItemArray[6].ToString();
        string type=dt.Rows[c].ItemArray[7].ToString();
        try
        {
            if(type.Equals("Cash"))
            {
                rdbCash.Checked = true; rdbCheque.Checked = false; txtCheque.Enabled = false; rdbSwap.Checked = false; rdbEPayment.Checked = false;
            }
            else if(type.Equals("Cheque"))
            {
                rdbCash.Checked = false; rdbCheque.Checked = true; txtCheque.Enabled = true; rdbSwap.Checked = false; rdbEPayment.Checked = false;
            }
            else if (type.Equals("Swap"))
            {
                rdbCash.Checked = false; rdbCheque.Checked = false; txtCheque.Enabled = false; rdbSwap.Checked = true; rdbEPayment.Checked = false;
            }
            else if (type.Equals("E-Payment"))
            {
                rdbCash.Checked = false; rdbCheque.Checked = false; txtCheque.Enabled = false; rdbSwap.Checked = false; rdbEPayment.Checked = true;
            }
        }
        catch(Exception ee){Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"')</script>");}
        txtCheque.Text = dt.Rows[c].ItemArray[8].ToString();
        txtAmt.Text=dt.Rows[c].ItemArray[9].ToString();
        ddlcby.Text=dt.Rows[c].ItemArray[10].ToString();
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(DId) from Donation",cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString())+1;
                txtDId.Text = j.ToString();
            }
            dr.Close();
        }
        catch(Exception ee)
        {
            txtDId.Text = "1";
            dr.Close();
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecords();
            ViewState["c"] = c.ToString();

        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Further Record..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Previous Record..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecords();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
                string s = null, t = null;
                if (rdbm.Checked == true)
                {
                    s = "male";
                }
                else if (rdbf.Checked == true)
                {
                    s = "female";
                }
                else if (rdbo.Checked == true)
                {
                    s = "other";
                }
                if (rdbCash.Checked == true)
                {
                    t = "Cash";
                }
                else if (rdbCheque.Checked == true)
                {
                    t = "Cheque";
                }
                else if (rdbSwap.Checked == true)
                {
                    t = "Swap";
                }
                else if (rdbEPayment.Checked == true)
                {
                    t = "rdbE-Payment";
                }
                if (t == "Cheque")
                {
                    cm = new SqlCommand("insert into Donation values(@d1," + int.Parse(txtDId.Text) + ",'" + txtDnm.Text + "','" + txtAddrs.Text + "'," + Int64.Parse(txtCon.Text) + ",'" + s + "','" + txtEid.Text + "','" + t + "','" + txtCheque.Text + "','" + Int64.Parse(txtAmt.Text) + "','" + ddlcby.SelectedItem + "')", cn);
                    cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                    int z = cm.ExecuteNonQuery();
                    if (z == 1)
                    {
                        Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                    }
                }
                else
                {
                    cm = new SqlCommand("insert into Donation values(@d1," + int.Parse(txtDId.Text) + ",'" + txtDnm.Text + "','" + txtAddrs.Text + "'," + Int64.Parse(txtCon.Text) + ",'" + s + "','" + txtEid.Text + "','" + t + "','None','" + Int64.Parse(txtAmt.Text) + "','" + ddlcby.SelectedItem + "')", cn);
                    cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                    int z = cm.ExecuteNonQuery();
                    if (z == 1)
                    {
                        Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                    }
                }
                try
                {
                    sendSMS(txtCon.Text);
                }
                catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Internet Connection For Sending SMS!..');</script>"); }
                clr();
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Inserted successfully !..');</script>");
        }
    }
    public string sendSMS(string no)
    {
            String result;
            string apiKey = "v+JmIgh3PtA-DdQu6ZfyxXAx9kZgqtkjvXHTIWCxIF";
            string numbers = no;// in a comma seperated list
            string message = "Donation Is Done To The Kunkeshwar Temple. Thank You For Donation!..";
            string sender = "TXTLCL";

            String url = "https://api.textlocal.in/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + sender;
            //refer to parameters to complete correct url string

            StreamWriter myWriter = null;
            HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

            objRequest.Method = "POST";
            objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
            objRequest.ContentType = "application/x-www-form-urlencoded";
            try
            {
                myWriter = new StreamWriter(objRequest.GetRequestStream());
                myWriter.Write(url);
            }
            catch (Exception e)
            {
                return e.Message;
            }
            finally
            {
                myWriter.Close();
            }

            HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
            using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
            {
                result = sr.ReadToEnd();
                // Close and clean up the StreamReader
                sr.Close();
            }
            return result;
        }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            string s = null, t = null;
            if (rdbm.Checked == true)
            {
                s = "male";
            }
            else if (rdbf.Checked == true)
            {
                s = "female";
            }
            else if (rdbo.Checked == true)
            {
                s = "other";
            }
            if (rdbCash.Checked == true)
            {
                t = "Cash";
            }
            else if (rdbCheque.Checked == true)
            {
                t = "Cheque";
            }
            else if (rdbSwap.Checked == true)
            {
                t = "Swap";
            }
            else if (rdbEPayment.Checked == true)
            {
                t = "rdbE-Payment";
            }
            cm = new SqlCommand("update Donation set DToday=@d1,Donatornm='"+txtDnm.Text+"',Addrs='"+txtAddrs.Text+"',ContactNo='"+txtCon.Text+"',Gender='"+s+"',Email='"+txtEid.Text+"',DType='"+t+"',Amt="+int.Parse(txtAmt.Text)+",DRBy='"+ddlcby.Text+"' where DId="+int.Parse(txtDId.Text)+"",cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated Successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully !..');</script>");
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from Donation where DId="+int.Parse(txtDId.Text)+"", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted Successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Deleted Successfully !..');</script>");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtDId.Text = "";
        txtDnm.Text = "";
        txtAddrs.Text = "";
        txtAmt.Text = "";
        txtCon.Text = "";
        txtEid.Text = "";
        ddlcby.Text = "";
        txtCheque.Text = "";
        rdbCheque.Checked = false;
        rdbCash.Checked = false;
        rdbf.Checked = false;
        rdbm.Checked = false;
        rdbo.Checked = false;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt1.Clear();
            cm = new SqlCommand("select * from Donation where DId like( '" + int.Parse(txtDId.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt1.Load(dr);
            dr.Close();
            lblToday.Text = dt1.Rows[0].ItemArray[0].ToString();
            txtDId.Text = dt1.Rows[0].ItemArray[1].ToString();
            txtDnm.Text = dt1.Rows[0].ItemArray[2].ToString();
            txtAddrs.Text = dt1.Rows[0].ItemArray[3].ToString();
            txtCon.Text = dt1.Rows[0].ItemArray[4].ToString();
            string gen = dt1.Rows[0].ItemArray[5].ToString();
            try
            {
                if (gen.Equals("male"))
                {
                    rdbm.Checked = true; rdbf.Checked = false; rdbo.Checked = false;
                }
                else if (gen.Equals("female"))
                {
                    rdbf.Checked = true; rdbm.Checked = false; rdbo.Checked = false;
                }
                else if (gen.Equals("other"))
                {
                    rdbo.Checked = true; rdbm.Checked = false; rdbf.Checked = false;
                }
            }
            catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
            txtEid.Text = dt1.Rows[0].ItemArray[6].ToString();
            string type = dt1.Rows[0].ItemArray[7].ToString();
            try
            {
                if (type.Equals("Cash"))
                {
                    rdbCash.Checked = true; rdbCheque.Checked = false; txtCheque.Enabled = false;
                }
                else if (type.Equals("Cheque"))
                {
                    rdbCash.Checked = false; rdbCheque.Checked = true; txtCheque.Enabled = true;
                }
            }
            catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "')</script>"); }
            txtCheque.Text = dt1.Rows[0].ItemArray[8].ToString();
            txtAmt.Text = dt1.Rows[0].ItemArray[9].ToString();
            ddlcby.Text = dt1.Rows[0].ItemArray[10].ToString();
        }
        catch (Exception ee) { clr(); }
    }
}