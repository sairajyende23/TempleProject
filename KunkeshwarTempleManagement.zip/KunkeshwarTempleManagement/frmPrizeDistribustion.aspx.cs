﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmPrizeDistribustion : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm,cm1;
    SqlDataReader dr,dr1;
    DataTable dt,dt1,dt2;
    int c,i,j, n,n1;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from PrizeDistribution", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void seeRecord()
    {
        try
        {
            txtSrNo.Text = dt.Rows[c].ItemArray[0].ToString();
            ddlEId.Text = dt.Rows[c].ItemArray[1].ToString();
            txtnm.Text = dt.Rows[c].ItemArray[2].ToString();
            txtDate.Text = dt.Rows[c].ItemArray[3].ToString();
            ddlPrizeNo.Text = dt.Rows[c].ItemArray[4].ToString();
            txtAmt.Text = dt.Rows[c].ItemArray[5].ToString();
            txtDistributedBy.Text = dt.Rows[c].ItemArray[6].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Previous Record !..');</script>"); }
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {       
        enable();
        newId();
        select();
    }
    protected void enable()
    {
        txtAmt.Enabled = true;
        txtDate.Enabled = true;
        txtDistributedBy.Enabled = true;
        txtnm.Enabled = true;
        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;
        btnAdd.Enabled = true;
        btnUpdate.Enabled = true;
        btnDelete.Enabled = true;
        btnClear.Enabled = true;
        btnDisplay.Enabled = true;
        txtSrNo.Enabled = true;
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(SrNo) from PrizeDistribution", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtSrNo.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtSrNo.Text = "1";
            dr.Close();
        }
    }
    protected void select()
    {
        ddlEId.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select EventId from Event", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlEId.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
        }
    }
    protected void btnDisplay_Click(object sender, EventArgs e)
    {
        int kk = int.Parse(ddlEId.SelectedItem.ToString());
        show(kk);
    }
    private void show(int kk)
    {
        cm1 = new SqlCommand("select * from Event where EventId=" + kk, cn);
        dr1 = cm1.ExecuteReader();
        if (dr1.Read())
        {
            txtnm.Text = dr1[1].ToString();          
        }
        dr1.Close();
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        c = 0;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Previous Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Further Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("insert into PrizeDistribution values(" + int.Parse(txtSrNo.Text) + "," + int.Parse(ddlEId.SelectedItem.ToString()) + ",'" + txtnm.Text + "',@d1,'" + ddlPrizeNo.SelectedItem + "'," + int.Parse(txtAmt.Text) + ",'" + txtDistributedBy.Text + "')", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtDate.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert(" + ee.ToString() + ");</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update PrizeDistribution set EventId=" + int.Parse(ddlEId.SelectedItem.ToString()) + ",EventNm='" + txtnm.Text + "',Date=@d1,PrizeNo='" + ddlPrizeNo.SelectedItem + "',PrizeAmt=" + int.Parse(txtAmt.Text) + ",DisributedBy='" + txtDistributedBy.Text + "' where SrNo=" + int.Parse(txtSrNo.Text) + "", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtDate.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from PrizeDistribution where SrNo=" + int.Parse(txtSrNo.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Deleted successfully !..');</script>");
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtAmt.Text = "";
        txtDistributedBy.Text = "";
        txtDate.Text = "";
        txtnm.Text = "";
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtDate.Text = @Calendar1.SelectedDate.ToShortDateString();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt2.Clear();
            cm = new SqlCommand("select * from PrizeDistribution where SrNo like( '" + int.Parse(txtSrNo.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt2.Load(dr);
            dr.Close();
            txtSrNo.Text = dt2.Rows[0].ItemArray[0].ToString();
            ddlEId.Text = dt2.Rows[0].ItemArray[1].ToString();
            txtnm.Text = dt2.Rows[0].ItemArray[2].ToString();
            txtDate.Text = dt2.Rows[0].ItemArray[3].ToString();
            ddlPrizeNo.Text = dt2.Rows[0].ItemArray[4].ToString();
            txtAmt.Text = dt2.Rows[0].ItemArray[5].ToString();
            txtDistributedBy.Text = dt2.Rows[0].ItemArray[6].ToString();
        }
        catch (Exception ee) { clr(); }
    }
}