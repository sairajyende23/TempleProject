﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class RoomLeaving : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm, cm1,cm2,cm3,cm4;
    SqlDataReader dr,dr1;
    DataTable dt, dt1;
    int k, j, i, c, n, n1,b;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        lblTDate.Text = DateTime.Now.ToShortDateString();
        
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        allRecords();
    }
    private void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from RoomLeaving", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>"); }
    }
    private void seeRecords()
    {
        lblTDate.Text = dt.Rows[c].ItemArray[0].ToString();
        txtLId.Text = dt.Rows[c].ItemArray[1].ToString();
        ddlBId.Text = dt.Rows[c].ItemArray[2].ToString();
        txtBDate.Text = dt.Rows[c].ItemArray[3].ToString();
        txtRoom.Text = dt.Rows[c].ItemArray[4].ToString();
        ddlCName.Text = dt.Rows[c].ItemArray[5].ToString();
        txtAddrs.Text = dt.Rows[c].ItemArray[6].ToString();
        txtCon.Text = dt.Rows[c].ItemArray[7].ToString();
        ddlId.Text = dt.Rows[c].ItemArray[8].ToString();
        txtAmt.Text = dt.Rows[c].ItemArray[9].ToString();
        ddlBby.Text = dt.Rows[c].ItemArray[10].ToString();     
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(LId) from RoomLeaving", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtLId.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtLId.Text = "1";
            dr.Close();
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No any Record !...');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Further Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecords();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            b = int.Parse(ddlBId.Text);
            cm = new SqlCommand("insert into RoomLeaving values(@d1," + int.Parse(txtLId.Text) + "," + int.Parse(ddlBId.SelectedItem.ToString()) + ",@d2," + int.Parse(txtRoom.Text) + ",'" + ddlCName.SelectedItem + "','" + txtAddrs.Text + "','" + Int64.Parse(txtCon.Text) + "','" + ddlId.SelectedItem + "','" + Int64.Parse(txtAmt.Text) + "','" + ddlBby.SelectedItem + "')", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblTDate.Text).ToShortDateString();
            cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtBDate.Text).ToShortDateString();            
            cm2 = new SqlCommand("update RoomBooking set status='Released' where BNo=" + int.Parse(ddlBId.Text) + "", cn);
            cm3 = new SqlCommand("update RoomMaster set status='Released' where RoomNo=" + int.Parse(txtRoom.Text) + "", cn);
            cm4 = new SqlCommand("update Customer set status='Released' where CName='" + ddlCName.SelectedItem + "'", cn);
            //cm3 = new SqlCommand("delete from RoomBooking where BNo=" + int.Parse(ddlBId.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            int z1 = cm2.ExecuteNonQuery();
            int z3 = cm3.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
            }
            if (z1 == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Booked Room is Released !...');</script>");
            }
            if (z3 == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record updated in RoomMaster successfully !..');</script>");
            }
            clr(); 
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted Successfully !..');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update RoomLeaving set TDate=@d1,BNo="+int.Parse(ddlBId.SelectedItem.ToString())+",Bdate=@d2,RoomNo="+int.Parse(txtRoom.Text)+",CName='"+ddlCName.SelectedItem+"',Address='"+txtAddrs.Text+"',ContactNo='"+Int64.Parse(txtCon.Text)+"',IdCard='"+ddlId.SelectedItem+"',TotAmount='"+Int64.Parse(txtAmt.Text)+"',BookedBy='"+ddlBby.SelectedItem+"' where LId="+int.Parse(txtLId.Text)+"",cn);          
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblTDate.Text).ToShortDateString();
            cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtBDate.Text).ToShortDateString();            
           
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");              
                clr();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from RoomLeaving where LId="+int.Parse(txtLId.Text)+"", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");           
                clr();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully !..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtLId.Text = "";
        txtBDate.Text = "";
        txtRoom.Text = "";
        txtAddrs.Text = "";
        txtCon.Text = "";
        txtAmt.Text = ""; 
    }
    protected void btnshowBID_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        select();
    }
    protected void enable()
    {
        txtAddrs.Enabled = true;
        txtAmt.Enabled = true;
        txtBDate.Enabled = true;
        txtCon.Enabled = true;
        txtLId.Enabled = true;
        txtRoom.Enabled = true;
        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;
        btnAdd.Enabled = true;
        btnUpdate.Enabled = true;
        btnDelete.Enabled = true;
        btnClear.Enabled = true;
        btnclick.Enabled = true;
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(LId) from RoomLeaving",cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtLId.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtLId.Text = "1";
            dr.Close();
        }
    }
    private void select()
    {
        ddlBId.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select * from RoomBooking", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlBId.Items.Add(dt1.Rows[i].ItemArray[1].ToString());
            ddlCName.Items.Add(dt1.Rows[i].ItemArray[4].ToString());
        }
    }
    protected void btnclick_Click(object sender, EventArgs e)
    {
        int k1 = int.Parse(ddlBId.SelectedItem.ToString());
        show(k1);
    }
    protected void show(int k1)
    {
        cm1 = new SqlCommand("select * from RoomBooking where BNo="+k1,cn);
        dr1 = cm1.ExecuteReader();
        if (dr1.Read())
        {
            txtBDate.Text=dr1[2].ToString();
            txtRoom.Text=dr1[3].ToString();
            ddlCName.Text=dr1[4].ToString();
            txtAddrs.Text=dr1[5].ToString();
            txtCon.Text=dr1[6].ToString();
            ddlId.Text=dr1[7].ToString();
        }
    }
}