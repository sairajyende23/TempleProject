﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmEventEnrollment : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm,cm1,cm2;
    SqlDataReader dr,dr1,dr2;
    DataTable dt,dt1,dt2;
    int i,j,n,c,n1,n2;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        lblToday.Text = DateTime.Now.Date.ToShortDateString();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    private void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from EventEnrollment", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        } 
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    private void seeRecord()
    {
        try
        {
            txtSrNo.Text=dt.Rows[c].ItemArray[0].ToString();
            lblToday.Text = dt.Rows[c].ItemArray[1].ToString();
            ddlEId.Text = dt.Rows[c].ItemArray[2].ToString();
            txtENm.Text = dt.Rows[c].ItemArray[3].ToString();
            txtStart.Text = dt.Rows[c].ItemArray[4].ToString();
            txtEnd.Text = dt.Rows[c].ItemArray[5].ToString();
            txtAgeGroup.Text=dt.Rows[c].ItemArray[6].ToString();
            txtPNm.Text = dt.Rows[c].ItemArray[7].ToString();
            txtPAddrs.Text = dt.Rows[c].ItemArray[8].ToString();
            txtcon.Text = dt.Rows[c].ItemArray[9].ToString();
            ddlHead.Text = dt.Rows[c].ItemArray[10].ToString();
            txtFee.Text = dt.Rows[c].ItemArray[11].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record !..');</script>"); }
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        selectId();
        selectHead();
    }
    protected void enable()
    {
        txtSrNo.Enabled = true;
        txtcon.Enabled = true;
        txtEnd.Enabled = true;
        txtENm.Enabled = true;
        txtFee.Enabled = true;
        txtPAddrs.Enabled = true;
        txtStart.Enabled = true;
        txtAgeGroup.Enabled = true;
        txtPNm.Enabled = true;

        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;

        btnAdd.Enabled = true;
        btnUpdate.Enabled = true;
        btnDelete.Enabled = true;
        btnClear.Enabled = true;
        btnDisplay.Enabled = true;
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(SrNo) from EventEnrollment", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtSrNo.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtSrNo.Text = "1";
            dr.Close();
        }
    }
    protected void selectId()
    {
        ddlEId.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select EventId from Event", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlEId.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
        }
    }
    protected void selectHead()
    {
        ddlHead.Items.Clear();
        dt2.Clear();
        cm2 = new SqlCommand("select DName from Designation", cn);
        dr2 = cm2.ExecuteReader();
        dt2.Load(dr2);
        dr2.Close();
        n2 = dt2.Rows.Count - 1;
        for (i = 0; i <= n2; i++)
        {
            ddlHead.Items.Add(dt2.Rows[i].ItemArray[0].ToString());
        }
    }
    protected void btnDisplay_Click(object sender, EventArgs e)
    {
        int kk=int.Parse(ddlEId.SelectedItem.ToString());
        show(kk);
    }
    private void show(int kk)
    {
        cm1 = new SqlCommand("select * from Event where EventId=" + kk, cn);
        dr1 = cm1.ExecuteReader();
        if (dr1.Read())
        {
            txtENm.Text = dr1[1].ToString();
            txtStart.Text = dr1[2].ToString();
            txtEnd.Text = dr1[3].ToString();
            txtAgeGroup.Text = dr1[6].ToString();
        }
        dr1.Close();
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        c = 0;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Previous Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Further Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
                cm = new SqlCommand("insert into EventEnrollment values("+int.Parse(txtSrNo.Text)+",@d1," + int.Parse(ddlEId.SelectedItem.ToString()) + ",'" + txtENm.Text + "',@d2,@d3,'" + txtAgeGroup.Text + "','" + txtPNm.Text + "','" + txtPAddrs.Text + "'," + Int64.Parse(txtcon.Text) + ",'" + ddlHead.SelectedItem + "'," + Int64.Parse(txtFee.Text) + ")", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtStart.Text).ToShortDateString();
                cm.Parameters.Add("@d3", SqlDbType.DateTime).Value = DateTime.Parse(txtEnd.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                    clr();
                }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted successfully');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update EventEnrollment set EToday='" + lblToday.Text + "',EId=" + int.Parse(ddlEId.SelectedItem.ToString()) + ",EventName='" + txtENm.Text + "',StartDate=@d1,EndDate=@d2,Agegroup='" + txtAgeGroup.Text + "',ParticipantNm='" + txtPNm.Text + "',ParticipantAddrs='" + txtPAddrs.Text + "',ParticipantContact='" + txtcon.Text + "',EventHead='" + ddlHead.Text + "',Fee=" + Int64.Parse(txtFee.Text) + " where SrNo="+int.Parse(txtSrNo.Text)+"", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtStart.Text).ToShortDateString();
            cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtEnd.Text).ToShortDateString();            
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from EventEnrollment where SrNo=" + int.Parse(txtSrNo.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Deleted successfully !..');</script>");
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    private void clr()
    {
        txtSrNo.Text = "";
        txtcon.Text="";
        txtEnd.Text = "";
        txtENm.Text="";
        txtFee.Text = "";
        txtPAddrs.Text = "";
        txtStart.Text = "";
        txtAgeGroup.Text = "";
        txtPNm.Text = "";
    }
}