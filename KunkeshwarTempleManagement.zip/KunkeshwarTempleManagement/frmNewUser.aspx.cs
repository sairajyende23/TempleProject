﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmNewUser : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt;
    int j,n;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        allRecords();
      //  newId();
    }
    protected void allRecords()
    {
        dt.Clear();
        cm = new SqlCommand("select * from Login",cn);
        dr = cm.ExecuteReader();
        dt.Load(dr);
        dr.Close();
    }
    protected void newId()
    {
        try
        {
            cm = new SqlCommand("select max(userId) from Login",cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString())+1;
                txtId.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtId.Text="1";
            dr.Close();
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (txtPass.Text == txtCPass.Text)
        {
            //cm = new SqlCommand("insert into Login values(" + int.Parse(txtId.Text) + ",'" + txtUnm.Text + "','" + txtPass.Text + "','" + txtCPass.Text + "','" + txtIce.Text + "','" + txtActor.Text + "','" + txtGame.Text + "')", cn);
            cm = new SqlCommand("update Login set username='"+txtUnm.Text+"',password='"+txtPass.Text+"',Icecream='"+txtIce.Text+"',Actor='"+txtActor.Text+"',Game='"+txtGame.Text+"' where userId="+int.Parse(txtId.Text)+"",cn);
            n = cm.ExecuteNonQuery();
            if (n==1)
            {
                Response.Write("<script type='text/javascript'>alert('New User Successfully !..');</script>");
                clr();
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('New User Not Created !..');</script>");
            }

        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('Password Does Not Match..Please Confirm the Password !...');</script>");
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtUnm.Text = "";
        txtPass.Text = "";
        txtIce.Text = "";
        txtActor.Text = "";
        txtGame.Text = "";
    }
}