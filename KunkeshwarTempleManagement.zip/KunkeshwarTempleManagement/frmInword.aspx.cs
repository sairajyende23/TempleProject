﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Inword : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt,dt1;
    int c,n;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1=new DataTable();
        lblToday.Text = DateTime.Now.ToShortDateString();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Inword",cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch(Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>"); 
        }
    }
    protected void seeRecord()
    {
        lblToday.Text = dt.Rows[c].ItemArray[0].ToString();
        txtInid.Text=dt.Rows[c].ItemArray[1].ToString();
        txtSnm.Text = dt.Rows[c].ItemArray[2].ToString();
        txtProduct.Text = dt.Rows[c].ItemArray[3].ToString();
        txtCon.Text = dt.Rows[c].ItemArray[4].ToString();
        txtAmount.Text = dt.Rows[c].ItemArray[5].ToString();
        ddlRby.Text = dt.Rows[c].ItemArray[6].ToString();
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(InwordId) from Inword", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
               int j = int.Parse(dr[0].ToString()) + 1;
                txtInid.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtInid.Text = "1";
            dr.Close();
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
            c = n;
            seeRecord();
            ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
                cm = new SqlCommand("insert into Inword values(@d1," + int.Parse(txtInid.Text) + ",'" + txtSnm.Text + "','" + txtProduct.Text + "','" + Int64.Parse(txtCon.Text) + "','" + Int64.Parse(txtAmount.Text) + "','" + ddlRby.SelectedItem + "')", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Inserted Successfully !..');</script>");
                }
                clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted successfully !..');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update Inword set InwordDate=@d1,SupplierNm='"+txtSnm.Text+"',ProductNm='"+txtProduct.Text+"',ContactNo='"+Int64.Parse(txtCon.Text)+"',Amount='"+Int64.Parse(txtAmount.Text)+"',ReceivedBy='"+ddlRby.SelectedItem+"' where InwordId="+int.Parse(txtInid.Text)+"",cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString(); 
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated Successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from Inword where InwordId="+int.Parse(txtInid.Text)+"",cn);
            int z = cm.ExecuteNonQuery();
            if(z==1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted Successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Deleted successfully !..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtInid.Text = "";
        txtSnm.Text = "";
        txtProduct.Text = "";
        txtCon.Text = "";
        txtAmount.Text = "";
        ddlRby.Text = "";
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt1.Clear();
            cm = new SqlCommand("select * from Inword where InwordId like( '" + int.Parse(txtInid.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt1.Load(dr);
            dr.Close();
            lblToday.Text = dt1.Rows[0].ItemArray[0].ToString();
            txtInid.Text = dt1.Rows[0].ItemArray[1].ToString();
            txtSnm.Text = dt1.Rows[0].ItemArray[2].ToString();
            txtProduct.Text = dt1.Rows[0].ItemArray[3].ToString();
            txtCon.Text = dt1.Rows[0].ItemArray[4].ToString();
            txtAmount.Text = dt1.Rows[0].ItemArray[5].ToString();
            ddlRby.Text = dt1.Rows[0].ItemArray[6].ToString();
        }
        catch (Exception ee) { clr(); }
    }
}