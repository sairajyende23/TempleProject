﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO.Ports;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.IO;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Net;

public partial class frmRoomBooking1 : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm, cm1;
    SqlDataReader dr, dr1;
    DataTable dt, dt1;
    int k, p, j, i, c, n, n1;
    string day, month, year, dayt, mont, yeart;
    protected void Page_Load(object sender, EventArgs e)
    {
         //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        lblTDate.Text = DateTime.Now.Date.ToShortDateString();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        fillRoom();
    }
    private void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from RoomBooking", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    private void seeRecords()
    {
        try
        {
            lblTDate.Text = dt.Rows[c].ItemArray[0].ToString();
            txtBookingNo.Text = dt.Rows[c].ItemArray[1].ToString();
            txtDate.Text = dt.Rows[c].ItemArray[2].ToString();
            txtRoom.Text = dt.Rows[c].ItemArray[3].ToString();
            ddlCName.Text = dt.Rows[c].ItemArray[4].ToString();
            txtAddrs.Text = dt.Rows[c].ItemArray[5].ToString();
            txtCon.Text = dt.Rows[c].ItemArray[6].ToString();
            ddlId.Text = dt.Rows[c].ItemArray[7].ToString();
            txtDays.Text = dt.Rows[c].ItemArray[8].ToString();
            txtAmt.Text = dt.Rows[c].ItemArray[9].ToString();
            if (dt.Rows[c].ItemArray[11].ToString().Equals("Booked"))
            {
                txtBookingNo.ForeColor = System.Drawing.Color.Red;
                txtDate.ForeColor = System.Drawing.Color.Red;
                txtRoom.ForeColor = System.Drawing.Color.Red;
                ddlCName.ForeColor = System.Drawing.Color.Red;
                txtAddrs.ForeColor = System.Drawing.Color.Red;
                txtCon.ForeColor = System.Drawing.Color.Red;
                ddlId.ForeColor = System.Drawing.Color.Red;
                txtDays.ForeColor = System.Drawing.Color.Red;
                txtAmt.ForeColor = System.Drawing.Color.Red;
            }
            else
            { fillBlack(); }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No any Record !..');</script>"); }
    }
    private void fillBlack()
    {
        txtBookingNo.ForeColor = System.Drawing.Color.Black;
        txtDate.ForeColor = System.Drawing.Color.Black;
        txtRoom.ForeColor = System.Drawing.Color.Black;
        ddlCName.ForeColor = System.Drawing.Color.Black;
        txtAddrs.ForeColor = System.Drawing.Color.Black;
        txtCon.ForeColor = System.Drawing.Color.Black;
        ddlId.ForeColor = System.Drawing.Color.Black;
        txtDays.ForeColor = System.Drawing.Color.Black;
        txtAmt.ForeColor = System.Drawing.Color.Black;
    }
   
    protected void btnshowBID_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        select();
        fillRoom(); txtAmt.Text = "1000";
    }
    protected void enable()
    {
        txtAddrs.Enabled = true;
        txtBookingNo.Enabled = true;
        txtCon.Enabled = true;

        txtDate.Enabled = true;
        txtDays.Enabled = true;
        txtRoom.Enabled = true;

        btnAdd.Enabled = true;
        btnclick.Enabled = true;
        btnClear.Enabled = true;
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(BNo) from RoomBooking", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtBookingNo.Text = j.ToString();
                fillRoom();
            }
            dr.Close();
            fillBlack();
        }
        catch (Exception ee)
        {
            txtBookingNo.Text = "1";
            dr.Close();
        }
    }
    private void select()
    {
        ddlCName.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select * from Customer where status='Booked'", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlCName.Items.Add(dt1.Rows[i].ItemArray[1].ToString());
        }
    }
    protected void btnclick_Click(object sender, EventArgs e)
    {
        string k1 = ddlCName.SelectedItem.ToString();
        show(k1); txtAmt.Text = "1000";
    }
    private void show(string k1)
    {
        cm1 = new SqlCommand("select * from Customer where CName=" + "'"+k1+"'", cn);
        dr1 = cm1.ExecuteReader();
        if (dr1.Read())
        {
            txtAddrs.Text = dr1[2].ToString();
            txtCon.Text = dr1[5].ToString();
        }
        dr1.Close();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            int r = int.Parse(txtRoom.Text);
            cm = new SqlCommand("insert into RoomBooking values(@d1," + int.Parse(txtBookingNo.Text) + ",@d2," + int.Parse(txtRoom.Text) + ",'" + ddlCName.SelectedItem + "','" + txtAddrs.Text + "'," + Int64.Parse(txtCon.Text) + ",'" + ddlId.SelectedItem + "'," + Int64.Parse(txtDays.Text) + "," + Int64.Parse(txtAmt.Text) + ",'" + ddlCName.SelectedItem + "','Booked')", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblTDate.Text).ToShortDateString();
            cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtDate.Text).ToShortDateString();
            cm1 = new SqlCommand("update RoomMaster set status='Booked' where RoomNo=" + int.Parse(txtRoom.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            int z1 = cm1.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                try
                {
                    sendSMS(txtCon.Text);
                }
                catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Internet Connection !..');</script>"); }
                fillRoom();
                clr();
            }
            //if (z1 == 1)
            //{
            //    Response.Write("<script type='text/javascript'>alert('Record updated in RoomMaster successfully !..');</script>");
            //}
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted successfully !..');</script>"); }
    }
    public string sendSMS(string no)
    {
        String result;
        string apiKey = "v+JmIgh3PtA-DdQu6ZfyxXAx9kZgqtkjvXHTIWCxIF";
        string numbers = no; // in a comma seperated list

        string message = "Room Booking Is Done. Thank You!..";
        string sender = "TXTLCL";

        String url = "https://api.textlocal.in/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + sender;
        //refer to parameters to complete correct url string

        StreamWriter myWriter = null;
        HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

        objRequest.Method = "POST";
        objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
        objRequest.ContentType = "application/x-www-form-urlencoded";
        try
        {
            myWriter = new StreamWriter(objRequest.GetRequestStream());
            myWriter.Write(url);
        }
        catch (Exception e)
        {
            return e.Message;
        }
        finally
        {
            myWriter.Close();
        }

        HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
        using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
        {
            result = sr.ReadToEnd();
            // Close and clean up the StreamReader
            sr.Close();
        }
        return result;
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtBookingNo.Text = "";
        txtAddrs.Text = "";
        txtAmt.Text = "";
        txtCon.Text = "";
        txtDate.Text = "";
        txtDays.Text = "";
        txtRoom.Text = "";
        lblStatus.Text = "";
    }
    protected void status()
    {
        int k1 = int.Parse(txtRoom.Text);
        for (i = 0; i <= n; i++)
        {
            int k2 = int.Parse(dt.Rows[i].ItemArray[3].ToString());
            string sta = dt.Rows[i].ItemArray[11].ToString();
            if (k1 == k2 && sta == "Booked")
            {
                DateTime s = DateTime.Parse(dt.Rows[i].ItemArray[2].ToString());
                int dd = int.Parse(dt.Rows[i].ItemArray[8].ToString());
                DateTime f = s.AddDays(dd);
                lblStatus.Text = k1 + "  No. Room Is Booked From " + s.Date.ToShortDateString() + "  to  " + f.Date.ToShortDateString(); ;
            }
        }
    }
    protected void btn1_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "1";
        status(); txtAmt.Text = "1000";
    }
    protected void btn2_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "2";
        status(); txtAmt.Text = "1000";
    }
    protected void btn3_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "3";
        status(); txtAmt.Text = "1000";
    }
    protected void btn4_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "4";
        status(); txtAmt.Text = "1000";
    }
    protected void btn5_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "5";
        status(); txtAmt.Text = "1000";
    }
    protected void btn6_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "6";
        status(); txtAmt.Text = "1000";
    }
    protected void btn7_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "7";
        status(); txtAmt.Text = "1000";
    }
    protected void btn8_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "8";
        status(); txtAmt.Text = "1000";
    }
    protected void btn9_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "9";
        status(); txtAmt.Text = "1000";
    }
    protected void btn10_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "10";
        status(); txtAmt.Text = "1000";
    }
    protected void btn11_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "11";
        status(); txtAmt.Text = "1000";
    }
    protected void btn12_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "12";
        status(); txtAmt.Text = "1000";
    }
    protected void btn13_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "13";
        status(); txtAmt.Text = "1000";
    }
    protected void btn14_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "14";
        status(); txtAmt.Text = "1000";
    }
    protected void btn15_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "15";
        status(); txtAmt.Text = "1000";
    }
    protected void btn16_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "16";
        status(); txtAmt.Text = "1000";
    }
    protected void btn17_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "17";
        status(); txtAmt.Text = "1000";
    }
    protected void btn18_Click(object sender, EventArgs e)
    {
        txtRoom.Text = "18";
        status(); txtAmt.Text = "1000";
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtDate.Text = @Calendar1.SelectedDate.Date.ToShortDateString();
    }
  private void fillRoom()
    {
        for (int i = 0; i <= n; i++)
        {
            string dd = DateTime.Now.ToShortDateString();
            string d = dt.Rows[i].ItemArray[2].ToString();

            day = d.Substring(0, 2);
            month =d.Substring(3, 2);
            year = d.Substring(6, 4);

            dayt = dd.Substring(0, 2);
            mont = dd.Substring(3, 2);
            yeart = dd.Substring(6, 4);
            
            string jk = year + month + day;
           
            string lk = yeart + mont + dayt;
         
            double jj = double.Parse(lk);
            double jjj = double.Parse(jk);
            double diiff = jj - jjj;
           
            int roomNo = int.Parse(dt.Rows[i].ItemArray[3].ToString());
            string status = dt.Rows[i].ItemArray[11].ToString();          
             if (status == "Booked")
             {
             if (diiff >= 0)
             {
                    switch (roomNo)
                    {
                          case 1:
                            {
                                btn1.BackColor = System.Drawing.Color.Red; //btn1.Enabled = false;
                                break;
                            }
                        case 2:
                            {
                                btn2.BackColor = System.Drawing.Color.Red; //btn2.Enabled = false;
                                break;
                            }
                        case 3:
                            {
                                btn3.BackColor = System.Drawing.Color.Red; //btn3.Enabled = false;
                                break;
                            }
                        case 4:
                            {
                                btn4.BackColor = System.Drawing.Color.Red; //btn4.Enabled = false;
                                break;
                            }
                        case 5:
                            {
                                btn5.BackColor = System.Drawing.Color.Red; //btn5.Enabled = false;
                                break;
                            }
                        case 6:
                            {
                                btn6.BackColor = System.Drawing.Color.Red; //btn6.Enabled = false;
                                break;
                            }
                        case 7:
                            {
                                btn7.BackColor = System.Drawing.Color.Red; //btn7.Enabled = false;
                                break;
                            }
                        case 8:
                            {
                                btn8.BackColor = System.Drawing.Color.Red; //btn8.Enabled = false;
                                break;
                            }
                        case 9:
                            {
                                btn9.BackColor = System.Drawing.Color.Red; //btn9.Enabled = false;
                                break;
                            }
                        case 10:
                            {
                                btn10.BackColor = System.Drawing.Color.Red; //btn10.Enabled = false;
                                break;
                            }
                        case 11:
                            {
                                btn11.BackColor = System.Drawing.Color.Red; //btn11.Enabled = false;
                                break;
                            }
                        case 12:
                            {
                                btn12.BackColor = System.Drawing.Color.Red; //btn12.Enabled = false;
                                break;
                            }
                        case 13:
                            {
                                btn13.BackColor = System.Drawing.Color.Red; //btn13.Enabled = false;
                                break;
                            }
                        case 14:
                            {
                                btn14.BackColor = System.Drawing.Color.Red; //btn14.Enabled = false;
                                break;
                            }
                        case 15:
                            {
                                btn15.BackColor = System.Drawing.Color.Red; //btn15.Enabled = false;
                                break;
                            }
                        case 16:
                            {
                                btn16.BackColor = System.Drawing.Color.Red; //btn16.Enabled = false;
                                break;
                            }
                        case 17:
                            {
                                btn17.BackColor = System.Drawing.Color.Red; //btn17.Enabled = false;
                                break;
                            }
                        case 18:
                            {
                                btn18.BackColor = System.Drawing.Color.Red; //btn18.Enabled = false;
                                break;
                            }
                    }
             }
             else
             {
                 autoFill(roomNo);
             }
             }
             else
             {
                 switch (roomNo)
                 {               
                    case 1:
                        {
                            btn1.BackColor = System.Drawing.Color.RoyalBlue; //btn1.Enabled = false;
                            break;
                        }
                    case 2:
                        {
                            btn2.BackColor = System.Drawing.Color.RoyalBlue; //btn2.Enabled = false;
                            break;
                        }
                    case 3:
                        {
                            btn3.BackColor = System.Drawing.Color.RoyalBlue; //btn3.Enabled = false;
                            break;
                        }
                    case 4:
                        {
                            btn4.BackColor = System.Drawing.Color.RoyalBlue; //btn4.Enabled = false;
                            break;
                        }
                    case 5:
                        {
                            btn5.BackColor = System.Drawing.Color.RoyalBlue; //btn5.Enabled = false;
                            break;
                        }
                    case 6:
                        {
                            btn6.BackColor = System.Drawing.Color.RoyalBlue; //btn6.Enabled = false;
                            break;
                        }
                    case 7:
                        {
                            btn7.BackColor = System.Drawing.Color.RoyalBlue; //btn7.Enabled = false;
                            break;
                        }
                    case 8:
                        {
                            btn8.BackColor = System.Drawing.Color.RoyalBlue; //btn8.Enabled = false;
                            break;
                        }
                    case 9:
                        {
                            btn9.BackColor = System.Drawing.Color.RoyalBlue; //btn9.Enabled = false;
                            break;
                        }
                    case 10:
                        {
                            btn10.BackColor = System.Drawing.Color.RoyalBlue; //btn10.Enabled = false;
                            break;
                        }
                    case 11:
                        {
                            btn11.BackColor = System.Drawing.Color.RoyalBlue; //btn11.Enabled = false;
                            break;
                        }
                    case 12:
                        {
                            btn12.BackColor = System.Drawing.Color.RoyalBlue; //btn12.Enabled = false;
                            break;
                        }
                    case 13:
                        {
                            btn13.BackColor = System.Drawing.Color.RoyalBlue; //btn13.Enabled = false;
                            break;
                        }
                    case 14:
                        {
                            btn14.BackColor = System.Drawing.Color.RoyalBlue; //btn14.Enabled = false;
                            break;
                        }
                    case 15:
                        {
                            btn15.BackColor = System.Drawing.Color.RoyalBlue; //btn15.Enabled = false;
                            break;
                        }
                    case 16:
                        {
                            btn16.BackColor = System.Drawing.Color.RoyalBlue; //btn16.Enabled = false;
                            break;
                        }
                    case 17:
                        {
                            btn17.BackColor = System.Drawing.Color.RoyalBlue; //btn17.Enabled = false;
                            break;
                        }
                    case 18:
                        {
                            btn18.BackColor = System.Drawing.Color.RoyalBlue; //btn18.Enabled = false;
                            break;
                        }
                 }
             }
        }
    }
    private void autoFill(int i)
    {
        switch (i)
        {
            case 1:
                {
                    btn1.BackColor = System.Drawing.Color.Lime;             //btn1.Enabled = true;
                    break;
                }
            case 2:
                {
                    btn2.BackColor = System.Drawing.Color.Lime;             //btn2.Enabled = true;
                    break;
                }
            case 3:
                {
                    btn3.BackColor = System.Drawing.Color.Lime;             //btn3.Enabled = true;
                    break;
                }
            case 4:
                {
                    btn4.BackColor = System.Drawing.Color.Lime;             //btn4.Enabled = true;
                    break;
                }
            case 5:
                {
                    btn5.BackColor = System.Drawing.Color.Lime;             // btn5.Enabled = true;
                    break;
                }
            case 6:
                {
                    btn6.BackColor = System.Drawing.Color.Lime;                        //btnRoom6.Enabled = true;
                    break;
                }
            case 7:
                {
                    btn7.BackColor = System.Drawing.Color.Lime;                       //btnRoom7.Enabled = true;
                    break;
                }
            case 8:
                {
                    btn8.BackColor = System.Drawing.Color.Lime;                        //btn8.Enabled = true;
                    break;
                }
            case 9:
                {
                    btn9.BackColor = System.Drawing.Color.Lime;                        //btn9.Enabled = true;
                    break;
                }
            case 10:
                {
                    btn10.BackColor = System.Drawing.Color.Lime;                        //btn10.Enabled = true;
                    break;
                }
            case 11:
                {
                    btn11.BackColor = System.Drawing.Color.Lime;                        //btn11.Enabled = true;
                    break;
                }
            case 12:
                {
                    btn12.BackColor = System.Drawing.Color.Lime;                      // btn12.Enabled = true;
                    break;
                }
            case 13:
                {
                    btn13.BackColor = System.Drawing.Color.Lime;                       //btn13.Enabled = true;
                    break;
                }
            case 14:
                {
                    btn14.BackColor = System.Drawing.Color.Lime;                      // btn14.Enabled = true;
                    break;
                }
            case 15:
                {
                    btn15.BackColor = System.Drawing.Color.Lime;                       // btn15.Enabled = true;
                    break;
                }
            case 16:
                {
                    btn16.BackColor = System.Drawing.Color.Lime;                      //btn16.Enabled = true;
                    break;
                }
            case 17:
                {
                    btn17.BackColor = System.Drawing.Color.Lime;                       //btn17.Enabled = true;
                    break;
                }
            case 18:
                {
                    btn18.BackColor = System.Drawing.Color.Lime;                        //btn18.Enabled = true;
                    break;
                }
        }
    }
    protected void ImgCalender_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible == false)
        {
            Calendar1.Visible = true;
        }
        else if (Calendar1.Visible == true)
        {
            Calendar1.Visible = false;
        }
    }
    protected void btnclickD_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/frmCustomerMaster.aspx");
    }
}