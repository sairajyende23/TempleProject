﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmOnlineElection : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm, cm1,cm2;
    SqlDataReader dr, dr1,dr2;
    DataTable dt, dt1,dt2;
    int c, i, j, n, n1,n2,flag;
    protected void Page_Load(object sender, EventArgs e)
    {

        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from OnlineElection", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void seeRecord()
    {
        try
        {
            lblTodysDate.Text = dt.Rows[c].ItemArray[0].ToString();
            txtETime.Text = dt.Rows[c].ItemArray[1].ToString();
            ddlFrom.Text = dt.Rows[c].ItemArray[2].ToString();
            ddlTo.Text = dt.Rows[c].ItemArray[3].ToString();
            ddlVoter.Text = dt.Rows[c].ItemArray[4].ToString();
            ddlVId.Text = dt.Rows[c].ItemArray[5].ToString();
            ddlM1.Text = dt.Rows[c].ItemArray[6].ToString();
            ddlM2.Text = dt.Rows[c].ItemArray[7].ToString();
            ddlM3.Text = dt.Rows[c].ItemArray[8].ToString();
            ddlM4.Text = dt.Rows[c].ItemArray[9].ToString();
            ddlM5.Text = dt.Rows[c].ItemArray[10].ToString();
            ddlM6.Text = dt.Rows[c].ItemArray[11].ToString();
            ddlM7.Text = dt.Rows[c].ItemArray[12].ToString();
            ddlM8.Text = dt.Rows[c].ItemArray[13].ToString();
            ddlM9.Text = dt.Rows[c].ItemArray[14].ToString();
            ddlM10.Text = dt.Rows[c].ItemArray[15].ToString();
            ddlM11.Text = dt.Rows[c].ItemArray[16].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Further Record !..');</script>"); }
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {
        enable();
        select1();
        lblTodysDate.Text = DateTime.Now.ToString();
        txtETime.Text = DateTime.Now.TimeOfDay.Hours.ToString() +":"+ DateTime.Now.TimeOfDay.Minutes.ToString();
    }
    protected void enable()
    {
        txtETime.Enabled = true;
        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;
        btnAdd.Enabled = true;
        btnDelete.Enabled = true;
    }
    protected void select1()
    {
        ddlVoter.Items.Clear();
        ddlVId.Items.Clear();
        ddlM1.Items.Clear();
        ddlM2.Items.Clear();
        ddlM3.Items.Clear();
        ddlM4.Items.Clear();
        ddlM5.Items.Clear();
        ddlM6.Items.Clear();
        ddlM7.Items.Clear();
        ddlM8.Items.Clear();
        ddlM9.Items.Clear();
        ddlM10.Items.Clear();
        ddlM11.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select * from CommityMember", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlVoter.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlVId.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
            ddlM1.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM2.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM3.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM4.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM5.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM6.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM7.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM8.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM9.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM10.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
            ddlM11.Items.Add(dt1.Rows[i].ItemArray[2].ToString());
        }

    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        c = 0;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString(); 
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            allRecords();
            flag = 0;
            cm2 = new SqlCommand("select VoterId from OnlineElection", cn);
            dr2 = cm2.ExecuteReader();
            dt2.Load(dr2);
            dr2.Close();
            n2 = dt2.Rows.Count - 1;
            for (i = 0; i <= n2; i++)
            {
                if (dt2.Rows[i].ItemArray[0].ToString() == ddlVId.SelectedItem.ToString())
                {
                    flag=1;
                    Response.Write("<script type='text/javascript'>alert('You are Trying to Revote..It Is Not Attempt !..');</script>");
                    clr();
                }
                else
                {
                    flag=0;
                }
            }
            if(flag==0)
            {
                    cm = new SqlCommand("insert into OnlineElection values(@d1,'" + txtETime.Text + "','" + ddlFrom.SelectedItem + "','" + ddlTo.SelectedItem + "','" + ddlVoter.SelectedItem + "','" + Int64.Parse(ddlVId.SelectedItem.ToString()) + "','" + ddlM1.SelectedItem + "','" + ddlM2.SelectedItem + "','" + ddlM3.SelectedItem + "','" + ddlM4.SelectedItem + "','" + ddlM5.SelectedItem + "','" + ddlM6.SelectedItem + "','" + ddlM7.SelectedItem + "','" + ddlM8.SelectedItem + "','" + ddlM9.SelectedItem + "','" + ddlM10.SelectedItem + "','" + ddlM11.SelectedItem + "')", cn);
                    cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblTodysDate.Text).ToShortDateString();
                    int z = cm.ExecuteNonQuery();
                    if (z == 1)
                    {
                        Response.Write("<script type='text/javascript'>alert('Record Inserted successfully..');</script>");
                        //flag = 1;
                        clr();
                    }
                }
              //  dr.Close();
           }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>");
        }//'Record Not Inserted Successfully..'
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update OnlineElection set EDate=@d1,ETime='" + txtETime.Text + "',Yfrom='" + ddlFrom.SelectedItem + "',YTo='" + ddlTo.SelectedItem + "',Voter='" + ddlVoter.SelectedItem + "',Member1='" + ddlM1.SelectedItem + "',Member2='" + ddlM2.SelectedItem + "',Member3='" + ddlM3.SelectedItem + "',Member4='" + ddlM4.SelectedItem + "',Member5='" + ddlM5.SelectedItem + "',Member6='" + ddlM6.SelectedItem + "',Member7='" + ddlM7.SelectedItem + "',Member8='" + ddlM8.SelectedItem + "',Member9='" + ddlM9.SelectedItem + "',Member10='" + ddlM10.SelectedItem + "',Member11='" + ddlM11.SelectedItem + "' where VoterId='" + Int64.Parse(ddlVId.SelectedItem.ToString()) + "'", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblTodysDate.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully !..');</script>");
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from OnlineElection where VoterId='" + Int64.Parse(ddlVId.SelectedItem.ToString()) + "'", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
                clr();
            }

        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtETime.Text = DateTime.Now.TimeOfDay.Hours.ToString() + ":" + DateTime.Now.TimeOfDay.Minutes.ToString();
    }
  

}