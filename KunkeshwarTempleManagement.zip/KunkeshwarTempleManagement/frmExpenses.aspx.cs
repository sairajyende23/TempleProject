﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmExpances : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt,dt1;
    int j, n, c;
    string p;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        lblChequeNo.Visible = false; txtChequeNo.Visible = false; lblBankNm.Visible = false; txtBankNm.Visible = false; txtBranch.Visible = false; lblBranch.Visible = false;
        lblToday.Text = DateTime.Now.ToShortDateString();
    }
    protected void rdbCheque_CheckedChanged(object sender, EventArgs e)
    {
        if (rdbCheque.Checked == true)
        {
            lblChequeNo.Visible = true; txtChequeNo.Visible = true; lblBankNm.Visible = true; txtBankNm.Visible = true; txtBranch.Visible = true; lblBranch.Visible = true;
        }
        else if (rdbCheque.Checked == false)
        {
            lblChequeNo.Visible = false; txtChequeNo.Visible = false; lblBankNm.Visible = false; txtBankNm.Visible = false; txtBranch.Visible = false; lblBranch.Visible = false;
        }
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(EId) from Expenses", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtEId.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtEId.Text = "1";
            dr.Close();
        }
    }
    private void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Expenses", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>");
        }
    }
    private void seeRecord()
    {
        lblToday.Text = dt.Rows[c].ItemArray[0].ToString();
        txtEId.Text=dt.Rows[c].ItemArray[1].ToString();
        txtTo.Text=dt.Rows[c].ItemArray[2].ToString();
        txtDetails.Text = dt.Rows[c].ItemArray[3].ToString();
        txtAmt.Text=dt.Rows[c].ItemArray[4].ToString();
        if (dt.Rows[c].ItemArray[5].ToString().Equals("Cash"))
        {
            rdbCash.Checked = true; rdbCheque.Checked = false; 
        }
        else if (dt.Rows[c].ItemArray[5].ToString().Equals("Cheque"))
        {
            rdbCheque.Checked = true; rdbCash.Checked = false;
            lblChequeNo.Visible = true; txtChequeNo.Visible = true; lblBankNm.Visible = true; txtBankNm.Visible = true; txtBranch.Visible = true; lblBranch.Visible = true;
        }
        txtChequeNo.Text = dt.Rows[c].ItemArray[6].ToString();
        txtBankNm.Text=dt.Rows[c].ItemArray[7].ToString();
        txtBranch.Text = dt.Rows[c].ItemArray[8].ToString();
        ddlEby.Text = dt.Rows[c].ItemArray[9].ToString();
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record..');</script>"); };
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Further Record..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Previous Record..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
            if (rdbCash.Checked == true)
            {
                p = "Cash";
            }
            else if (rdbCheque.Checked == true)
            {
                p = "Cheque";
            }
            try
            {
                if (p == "Cash")
                {
                    cm = new SqlCommand("insert into Expenses(EDate,EId,PaidTo,Details,Amount,PaidBy,EnteredBy) values(@d1," + int.Parse(txtEId.Text) + ",'" + txtTo.Text + "','" + txtDetails.Text + "','" + Int64.Parse(txtAmt.Text) + "','" + p + "','" + ddlEby.SelectedItem + "')", cn);
                    cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                    int z = cm.ExecuteNonQuery();
                    if (z == 1)
                    {
                        Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                        clr();
                    }
                }
                else if (p == "Cheque")
                {
                    cm = new SqlCommand("insert into Expenses values(@d1," + int.Parse(txtEId.Text) + ",'" + txtTo.Text + "','" + txtDetails.Text + "','" + Int64.Parse(txtAmt.Text) + "','" + p + "','" + txtChequeNo.Text + "','" + txtBankNm.Text + "','" + txtBranch.Text + "','" + ddlEby.SelectedItem + "')", cn);
                    cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                    int z = cm.ExecuteNonQuery();
                    if (z == 1)
                    {
                        Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                        clr();
                    }
                }
            }
            catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted successfully !...');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (rdbCash.Checked == true)
        {
            p = "Cash";
        }
        else if (rdbCheque.Checked == true)
        {
            p = "Cheque";
        }
        try
        {           
            if (p == "Cash")
            {
                cm = new SqlCommand("update Expenses(EDate,EId,PaidTo,Details,Amount,PaidBy,EnteredBy) set EDate=@d1,PaidTo='" + txtTo.Text + "',Details='" + txtDetails.Text + "',Amount='" + Int64.Parse(txtAmt.Text) + "',PaidBy='" + p + "',EnteredBy='" + ddlEby.SelectedItem + "' where EId=" + int.Parse(txtEId.Text) + "", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Updated Successfully !..');</script>");
                    clr();
                }
            }
            else if (p == "Cheque")
            {
                cm = new SqlCommand("update Expenses set EDate=@d1,PaidTo='" + txtTo.Text + "',Details='" + txtDetails.Text + "',Amount='" + Int64.Parse(txtAmt.Text) + "',PaidBy='" + p + "',ChequeNo='" + txtChequeNo.Text + "',BankName='" + txtBankNm.Text + "',Branch='" + txtBranch.Text + "',EnteredBy='" + ddlEby.SelectedItem + "' where EId=" + int.Parse(txtEId.Text) + "", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Updated Successfully !..');</script>");
                    clr();
                }
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Updated Successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from Expenses where EId=" + int.Parse(txtEId.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted Successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Deleted Successfully !..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtEId.Text = "";
        txtTo.Text = "";
        txtAmt.Text = "";
        txtChequeNo.Text = "";
        txtDetails.Text = "";
        rdbCash.Checked = false;
        rdbCheque.Checked = false;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt1.Clear();
            cm = new SqlCommand("select * from Expenses where EId like( '" + int.Parse(txtEId.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt1.Load(dr);
            dr.Close();
            lblToday.Text = dt1.Rows[0].ItemArray[0].ToString();
            txtEId.Text = dt1.Rows[0].ItemArray[1].ToString();
            txtTo.Text = dt1.Rows[0].ItemArray[2].ToString();
            txtDetails.Text = dt1.Rows[0].ItemArray[3].ToString();
            txtAmt.Text = dt1.Rows[0].ItemArray[4].ToString();
            if (dt1.Rows[0].ItemArray[5].ToString().Equals("Cash"))
            {
                rdbCash.Checked = true; rdbCheque.Checked = false;
            }
            else if (dt1.Rows[0].ItemArray[5].ToString().Equals("Cheque"))
            {
                rdbCheque.Checked = true; rdbCash.Checked = false;
                lblChequeNo.Visible = true; txtChequeNo.Visible = true; lblBankNm.Visible = true; txtBankNm.Visible = true; txtBranch.Visible = true; lblBranch.Visible = true;
            }
            txtChequeNo.Text = dt1.Rows[0].ItemArray[6].ToString();
            txtBankNm.Text = dt1.Rows[0].ItemArray[7].ToString();
            txtBranch.Text = dt1.Rows[0].ItemArray[8].ToString();
            ddlEby.Text = dt1.Rows[0].ItemArray[9].ToString();
        }
        catch (Exception ee) { clr(); }
    }
}