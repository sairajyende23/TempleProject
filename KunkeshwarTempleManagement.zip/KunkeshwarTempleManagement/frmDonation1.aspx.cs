﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO.Ports;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.IO;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Net;
public partial class frmDonation1 : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt;
    int j, n, c;
    protected void Page_Load(object sender, EventArgs e)
    {

        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        allRecords();
        lblToday.Text = DateTime.Now.ToShortDateString();
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(DId) from Donation", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtDId.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtDId.Text = "1";
            dr.Close();
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Donation", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>");
        }
    }
    protected void seeRecords()
    {
        lblToday.Text = dt.Rows[c].ItemArray[0].ToString();
        txtDId.Text = dt.Rows[c].ItemArray[1].ToString();
        txtDnm.Text = dt.Rows[c].ItemArray[2].ToString();
        txtAddrs.Text = dt.Rows[c].ItemArray[3].ToString();
        txtCon.Text = dt.Rows[c].ItemArray[4].ToString();
        string gen = dt.Rows[c].ItemArray[5].ToString();
        try
        {
            if (gen.Equals("male"))
            {
                rdbm.Checked = true; rdbf.Checked = false; rdbo.Checked = false;
            }
            else if (gen.Equals("female"))
            {
                rdbf.Checked = true; rdbm.Checked = false; rdbo.Checked = false;
            }
            else if (gen.Equals("other"))
            {
                rdbo.Checked = true; rdbm.Checked = false; rdbf.Checked = false;
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
        txtEid.Text = dt.Rows[c].ItemArray[6].ToString();
        string type = dt.Rows[c].ItemArray[7].ToString();
        try
        {
           
            if (type.Equals("Cheque"))
            {
                rdbCheque.Checked = true; txtCheque.Enabled = true;
            }
            else if (type.Equals("Swap"))
            {
                rdbCheque.Checked = false; txtCheque.Enabled = false; rdbSwap.Checked = true; rdbEPayment.Checked = false;
            }
            else if (type.Equals("E-Payment"))
            {
                rdbCheque.Checked = false; txtCheque.Enabled = false; rdbSwap.Checked = false; rdbEPayment.Checked = true;
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "')</script>"); }
        txtCheque.Text = dt.Rows[c].ItemArray[8].ToString();
        txtAmt.Text = dt.Rows[c].ItemArray[9].ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            string s = null, t = null;
            if (rdbm.Checked == true)
            {
                s = "male";
            }
            else if (rdbf.Checked == true)
            {
                s = "female";
            }
            else if (rdbo.Checked == true)
            {
                s = "other";
            }
            if (rdbCheque.Checked == true)
            {
                t = "Cheque";
            }
            else if (rdbSwap.Checked == true)
            {
                t = "Swap";
            }
            else if (rdbEPayment.Checked == true)
            {
                t = "E-Payment";
            }
            if (t == "Cheque")
            {
                cm = new SqlCommand("insert into Donation values(@d1," + int.Parse(txtDId.Text) + ",'" + txtDnm.Text + "','" + txtAddrs.Text + "'," + Int64.Parse(txtCon.Text) + ",'" + s + "','" + txtEid.Text + "','" + t + "','" + txtCheque.Text + "','" + Int64.Parse(txtAmt.Text) + "','" + txtDnm.Text + "')", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                }
            }
            else
            {
                cm = new SqlCommand("insert into Donation values(@d1," + int.Parse(txtDId.Text) + ",'" + txtDnm.Text + "','" + txtAddrs.Text + "','" + Int64.Parse(txtCon.Text) + "','" + s + "','" + txtEid.Text + "','" + t + "','None','" + Int64.Parse(txtAmt.Text) + "','" + txtDnm.Text + "')", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                }
            }
            try
            {
                sendSMS(txtCon.Text);
            }
            catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Internet Connection For Sending SMS!..');</script>"); }
            clr();
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Inserted successfully !..');</script>");
        }
    }
   public string sendSMS(string no)
    {
        String result;
        string apiKey = "v+JmIgh3PtA-DdQu6ZfyxXAx9kZgqtkjvXHTIWCxIF";
        string numbers = no; // in a comma seperated list

        string message = "Donation Is Done To The Kunkeshwar Temple. Thank You For Donation!..";
        string sender = "TXTLCL";

        String url = "https://api.textlocal.in/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + sender;
        //refer to parameters to complete correct url string

        StreamWriter myWriter = null;
        HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

        objRequest.Method = "POST";
        objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
        objRequest.ContentType = "application/x-www-form-urlencoded";
        try
        {
            myWriter = new StreamWriter(objRequest.GetRequestStream());
            myWriter.Write(url);
        }
        catch (Exception e)
        {
            return e.Message;
        }
        finally
        {
            myWriter.Close();
        }

        HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
        using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
        {
            result = sr.ReadToEnd();
            // Close and clean up the StreamReader
            sr.Close();
        }
        return result;
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtDId.Text = "";
        txtDnm.Text = "";
        txtAddrs.Text = "";
        txtAmt.Text = "";
        txtCon.Text = "";
        txtEid.Text = "";
        txtCheque.Text = "";
        rdbCheque.Checked = false;
        rdbf.Checked = false;
        rdbm.Checked = false;
        rdbo.Checked = false;
    }
    protected void btnNew_Click(object sender, System.EventArgs e)
    {
        newId();
    }
}