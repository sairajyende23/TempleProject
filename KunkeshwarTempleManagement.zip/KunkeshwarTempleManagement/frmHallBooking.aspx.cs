﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO.Ports;
using System.Data.SqlClient;
using System.Collections.Specialized;
using System.IO;
using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Net;


public partial class Notice : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt,dt1;
    int c,n,i,j;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        lblToday.Text = DateTime.Now.ToShortDateString();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        if (Session["login"] == null)
        {
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            btnFst.Visible = false;
            btnNext.Visible = false;
            btnPre.Visible = false;
            btnLast.Visible = false;
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from HallBooking",cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>"); }
    }
    protected void seeRecord()
    {
        txtNo.Text = dt.Rows[c].ItemArray[1].ToString();
        txtNm.Text = dt.Rows[c].ItemArray[2].ToString();
        txtCon.Text = dt.Rows[c].ItemArray[3].ToString();
        txtEvent.Text = dt.Rows[c].ItemArray[4].ToString();
        txtStart.Text = dt.Rows[c].ItemArray[5].ToString();
        txtEnd.Text = dt.Rows[c].ItemArray[6].ToString();
        txtAmt.Text = dt.Rows[c].ItemArray[7].ToString();
        ddlRby.Text = dt.Rows[c].ItemArray[8].ToString();
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        Bookdays();
    }
    protected void enable()
    {
        txtAmt.Enabled = true;
        txtCon.Enabled = true;
        txtEnd.Enabled = true;
        txtEvent.Enabled = true;
        txtNm.Enabled = true;

        txtNo.Enabled = true;
        txtStart.Enabled = true;
        btnAdd.Enabled = true;
        btnUpdate.Enabled = true;
        btnDelete.Enabled = true;

        btnClear.Enabled = true;
        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;

        btnEAdd.Enabled = true;
        btnSAdd.Enabled = true;
        btnClick.Enabled = true;

    }
    protected void Bookdays()
    {
        try
        {
            for (i = 0; i <= n; i++)
            {
                DateTime start = Convert.ToDateTime(dt.Rows[i].ItemArray[5]);
                int v1 = start.Day;
                DateTime end = Convert.ToDateTime(dt.Rows[i].ItemArray[6]);
                int v2 = end.Day;
                int a = 1;
                Calendar1.SelectedDates.Add(Convert.ToDateTime(start));
                while (v1 < v2)
                {
                    DateTime d3 = start.AddDays(a);
                    Calendar1.SelectedDates.Add(Convert.ToDateTime(d3));
                    Calendar1.SelectedDayStyle.BackColor = System.Drawing.Color.DeepPink;
                    v1++;
                    a++;
                }
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(SrNo) from HallBooking", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtNo.Text = j.ToString();
            }
        }
        catch (Exception ee)
        {
            txtNo.Text = "1";
            dr.Close();
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record..');</script>"); }
    }   
    protected void btnNext_Click(object sender, EventArgs e)
    {
            if (c < n)
            {
                c++;
                seeRecord();
                ViewState["c"] = c.ToString();
            }
            else
            {
             Response.Write("<script type='text/javascript'>alert('No Any Previous Record !..');</script>"); 
            }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Further Record !..');</script>"); 
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
                cm = new SqlCommand("insert into HallBooking values(@d1," + int.Parse(txtNo.Text) + ",'" + txtNm.Text + "','" + Int64.Parse(txtCon.Text) + "','" + txtEvent.Text + "',@d2,@d3,'" + Int64.Parse(txtAmt.Text) + "','" + ddlRby.SelectedItem + "')", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtStart.Text).ToShortDateString();
                cm.Parameters.Add("@d3", SqlDbType.DateTime).Value = DateTime.Parse(txtEnd.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                    try
                    {
                        sendSMS(txtCon.Text);
                    }
                    catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Internet Connection For Sending SMS!..');</script>"); }
                    clr();
                    Calendar1.SelectedDates.Clear();
                }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert("+ee.ToString()+");</script>"); }
    }
    public string sendSMS(string no)
    {
        String result;
        string apiKey = "v+JmIgh3PtA-DdQu6ZfyxXAx9kZgqtkjvXHTIWCxIF";
        string numbers = no; // in a comma seperated list

        string message = "Hall Booking Is Done. Thank You!..";
        string sender = "TXTLCL";

        String url = "https://api.textlocal.in/send/?apikey=" + apiKey + "&numbers=" + numbers + "&message=" + message + "&sender=" + sender;
        //refer to parameters to complete correct url string

        StreamWriter myWriter = null;
        HttpWebRequest objRequest = (HttpWebRequest)WebRequest.Create(url);

        objRequest.Method = "POST";
        objRequest.ContentLength = Encoding.UTF8.GetByteCount(url);
        objRequest.ContentType = "application/x-www-form-urlencoded";
        try
        {
            myWriter = new StreamWriter(objRequest.GetRequestStream());
            myWriter.Write(url);
        }
        catch (Exception e)
        {
            return e.Message;
        }
        finally
        {
            myWriter.Close();
        }

        HttpWebResponse objResponse = (HttpWebResponse)objRequest.GetResponse();
        using (StreamReader sr = new StreamReader(objResponse.GetResponseStream()))
        {
            result = sr.ReadToEnd();
            // Close and clean up the StreamReader
            sr.Close();
        }
        return result;
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update HallBooking set DToday=@d1,CustName='"+txtNm.Text+"',ContactNo='"+Int64.Parse(txtCon.Text)+"',Event='"+txtEvent.Text+"',StartDate=@d2,EndDate=@d3,Amount="+Int64.Parse(txtAmt.Text)+",ReceivedBy='"+ddlRby.SelectedItem+"' where SrNo="+int.Parse(txtNo.Text)+"",cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
            cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtStart.Text).ToShortDateString();
            cm.Parameters.Add("@d3", SqlDbType.DateTime).Value = DateTime.Parse(txtEnd.Text).ToShortDateString();            
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
                clr();
                Calendar1.SelectedDates.Clear();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from HallBooking where SrNo="+int.Parse(txtNo.Text)+"", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
                clr();
                Calendar1.SelectedDates.Clear();
            }
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Deleted successfully !..');</script>");   
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtNo.Text = "";
        txtNm.Text = "";
        txtEvent.Text = "";
        txtAmt.Text = "";
        txtCon.Text = "";
        txtStart.Text = "";
        txtEnd.Text = "";
    }
    protected void btnSAdd_Click(object sender, EventArgs e)
    {
        txtStart.Text = @Calendar1.SelectedDate.Date.ToShortDateString();
    }
    protected void btnEAdd_Click(object sender, EventArgs e)
    {
        txtEnd.Text = @Calendar1.SelectedDate.Date.ToShortDateString();
    }
    protected void btnClick_Click(object sender, EventArgs e)
    {
        Calendar1.SelectedDates.Clear();
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {

    }
    protected void btnSearch_Click(object sender, System.EventArgs e)
    {
        try
        {
            dt1.Clear();
            cm = new SqlCommand("select * from HallBooking where SrNo like( '" + int.Parse(txtNo.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt1.Load(dr);
            dr.Close();
            txtNo.Text = dt1.Rows[0].ItemArray[1].ToString();
            txtNm.Text = dt1.Rows[0].ItemArray[2].ToString();
            txtCon.Text = dt1.Rows[0].ItemArray[3].ToString();
            txtEvent.Text = dt1.Rows[0].ItemArray[4].ToString();
            txtStart.Text = dt1.Rows[0].ItemArray[5].ToString();
            txtEnd.Text = dt1.Rows[0].ItemArray[6].ToString();
            txtAmt.Text = dt1.Rows[0].ItemArray[7].ToString();
            ddlRby.Text = dt1.Rows[0].ItemArray[8].ToString();
        }
             catch (Exception ee) { clr(); }
    }
}