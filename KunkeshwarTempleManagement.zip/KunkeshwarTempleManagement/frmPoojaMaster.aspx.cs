﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class PoojaMaster : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt,dt1;
    int j, c, n;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from PoojaMast", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    private void seeRecords()
    {
        txtPId.Text = dt.Rows[c].ItemArray[0].ToString();
        txtnm.Text = dt.Rows[c].ItemArray[1].ToString(); 
        txtNo.Text = dt.Rows[c].ItemArray[2].ToString();
        txtDaksh.Text = dt.Rows[c].ItemArray[3].ToString();
        txtExp.Text = dt.Rows[c].ItemArray[4].ToString();         
        txtTotal.Text = dt.Rows[c].ItemArray[5].ToString();
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(PId) from PoojaMast", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtPId.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtPId.Text = "1";
            dr.Close();
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        c = 0;
        seeRecords();
        ViewState["c"] = c.ToString();
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecords();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
                cm = new SqlCommand("insert into PoojaMast values(" + int.Parse(txtPId.Text) + ",'" + txtnm.Text + "','" + Int64.Parse(txtNo.Text) + "','" + Int64.Parse(txtDaksh.Text) + "','" + Int64.Parse(txtExp.Text) + "','" + Int64.Parse(txtTotal.Text) + "')", cn);
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                }
                clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted Successfully !..');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update PoojaMast set PName='"+txtnm.Text+"',NoOfPurohit='"+Int64.Parse(txtNo.Text)+"',Dakshina='"+Int64.Parse(txtDaksh.Text)+"',Otherexpnces='"+Int64.Parse(txtExp.Text)+"',OtherDetails='"+Int64.Parse(txtTotal.Text)+"' where PId="+int.Parse(txtPId.Text)+"",cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from PoojaMast where PId=" + int.Parse(txtPId.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully !..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtPId.Text = "";
        txtnm.Text = "";
        txtExp.Text = "";
        txtDaksh.Text = "";
        txtTotal.Text = "";
        txtNo.Text = "";
    }
    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        txtTotal.Text = (float.Parse(txtDaksh.Text) + float.Parse(txtExp.Text)).ToString();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt1.Clear();
            cm = new SqlCommand("select * from PoojaMast where PId like( '" + int.Parse(txtPId.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt1.Load(dr);
            dr.Close();
            txtPId.Text = dt1.Rows[0].ItemArray[0].ToString();
            txtnm.Text = dt1.Rows[0].ItemArray[1].ToString();
            txtNo.Text = dt1.Rows[0].ItemArray[2].ToString();
            txtDaksh.Text = dt1.Rows[0].ItemArray[3].ToString();
            txtExp.Text = dt1.Rows[0].ItemArray[4].ToString();
            txtTotal.Text = dt1.Rows[0].ItemArray[5].ToString();
        }
        catch(Exception ee)
        {
            clr();
        }
    }
}