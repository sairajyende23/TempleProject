﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ForgotPassword : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        cm=new SqlCommand("select * from Login where userId="+txtUid.Text,cn);
        dr = cm.ExecuteReader();
        dt.Load(dr);
        dr.Close();
        if (txtUid.Text == dt.Rows[0].ItemArray[0].ToString())
        {
            if (txtUnm.Text == dt.Rows[0].ItemArray[1].ToString())
            {
                if(txtIce.Text==dt.Rows[0].ItemArray[3].ToString())
                {
                    if(txtActor.Text==dt.Rows[0].ItemArray[4].ToString())
                    {
                        if (txtGame.Text == dt.Rows[0].ItemArray[5].ToString())
                        {
                            Response.Write("<script type='text/javascript'>alert('Password is '+'"+dt.Rows[0].ItemArray[2].ToString()+"');</script>");
                            clr();
                        }
                        else
                        {
                            Response.Write("<script type='text/javascript'>alert('Game Does Not Match !...');</script>");
                        }
                    }
                    else
                    {
                        Response.Write("<script type='text/javascript'>alert('Actor Does Not Match !...');</script>");
                    }
                }
                else
                {
                    Response.Write("<script type='text/javascript'>alert('IceCream Flavour Does Not Match !...');</script>");
                }
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('User Name Does Not Match !...');</script>");
            }
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('User Id Is Incorrect !...');</script>");
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtUid.Text = "";
        txtUnm.Text = "";
        txtIce.Text = "";
        txtActor.Text = "";
        txtGame.Text = "";
    }
}