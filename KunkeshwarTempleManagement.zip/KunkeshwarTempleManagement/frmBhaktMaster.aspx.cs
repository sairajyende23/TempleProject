﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class BhaktMaster : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt, dt1;
    int j, n, c;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        if (Session["login"] == null)
        {
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            btnFst.Visible = false;
            btnNext.Visible = false;
            btnPre.Visible = false;
            btnLast.Visible = false;
            btnSearch.Visible = false;
            txtBId.ReadOnly = true;
        }
    }
    private void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from BhaktMast", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>");
        }
    }
    private void seeRecord()
    {
        txtBId.Text = dt.Rows[c].ItemArray[0].ToString();
        txtnm.Text = dt.Rows[c].ItemArray[1].ToString();
        txtfnm.Text = dt.Rows[c].ItemArray[2].ToString();
        txtmnm.Text = dt.Rows[c].ItemArray[3].ToString();
        txtaddrs.Text = dt.Rows[c].ItemArray[4].ToString();
        string gen = dt.Rows[c].ItemArray[5].ToString();
        try
        {
            if (gen.Equals("male"))
            {
                rdbm.Checked = true; rdbf.Checked = false; rdbo.Checked = false;
            }
            else if (gen.Equals("female"))
            {
                rdbf.Checked = true; rdbm.Checked = false; rdbo.Checked = false;
            }
            else if (gen.Equals("other"))
            {
                rdbo.Checked = true; rdbm.Checked = false; rdbf.Checked = false;
            }
        }
        catch (Exception ee) { Response.Write(ee.ToString()); }
        txtdob.Text = dt.Rows[c].ItemArray[6].ToString();
        txtage.Text = dt.Rows[c].ItemArray[7].ToString();
        txtgotra.Text = dt.Rows[c].ItemArray[8].ToString();
        txtkul.Text = dt.Rows[c].ItemArray[9].ToString();
        txtcon.Text = dt.Rows[c].ItemArray[10].ToString();
        txteid.Text = dt.Rows[c].ItemArray[11].ToString();
        ddlcby.Text = dt.Rows[c].ItemArray[12].ToString();
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record..');</script>"); };
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Further Record..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Previous Record..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            string s = null;
            if (rdbm.Checked == true)
            {
                s = "male";
            }
            else if (rdbf.Checked == true)
            {
                s = "female";
            }
            else if (rdbo.Checked == true)
            {
                s = "other";
            }
            cm = new SqlCommand("insert into BhaktMast values(" + int.Parse(txtBId.Text) + ",'" + txtnm.Text + "','" + txtfnm.Text + "','" + txtmnm.Text + "','" + txtaddrs.Text + "','" + s + "','" + txtdob.Text + "'," + int.Parse(txtage.Text) + ",'" + txtgotra.Text + "','" + txtkul.Text + "'," + Int64.Parse(txtcon.Text) + ",'" + txteid.Text + "','" + ddlcby.SelectedItem + "')", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted Successfully !..');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            string s = null;
            if (rdbm.Checked == true)
            {
                s = "male";
            }
            else if (rdbf.Checked == true)
            {
                s = "female";
            }
            else if (rdbo.Checked == true)
            {
                s = "other";
            }
            cm = new SqlCommand("update BhaktMast set bName='" + txtnm.Text + "',fName='" + txtnm.Text + "',mName='" + txtnm.Text + "',address='" + txtaddrs.Text + "',gender='" + s + "',DOfBirth='" + txtdob.Text + "',age=" + int.Parse(txtcon.Text) + ",gotra='" + txtgotra.Text + "',kuldevi='" + txtkul.Text + "',contactNo='" + Int64.Parse(txtcon.Text) + "',emailId='" + txteid.Text + "',dataChBy='" + ddlcby.SelectedItem + "' where bId=" + int.Parse(txtBId.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated Successfully !..');</script>");
            }
            clr();

        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Updated Successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from BhaktMast where bId=" + int.Parse(txtBId.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted Successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Deleted Successfully !..');</script>"); }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clr();
    }
    private void clr()
    {
        txtBId.Text = "";
        txtnm.Text = "";
        txtfnm.Text = "";
        txtmnm.Text = "";
        txtaddrs.Text = "";
        txtdob.Text = "";
        txtage.Text = "";
        txtgotra.Text = "";
        txtkul.Text = "";
        txtcon.Text = "";
        txteid.Text = "";
        rdbm.Checked = false;
        rdbf.Checked = false;
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(bId) from BhaktMast", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtBId.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtBId.Text = "1";
            dr.Close();
        }
    }
    protected void btnCalculate_Click(object sender, EventArgs e)
    {
        string y = txtdob.Text;
        DateTime dob = Convert.ToDateTime(y);
        DateTime current = Convert.ToDateTime(DateTime.Now);
        TimeSpan time = current.Subtract(dob);
        int age = (time.Days) / 365;
        txtage.Text = age.ToString();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt1.Clear();
            cm = new SqlCommand("select * from BhaktMast where bId like( '" + int.Parse(txtBId.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt1.Load(dr);
            dr.Close();
            txtBId.Text = dt1.Rows[0].ItemArray[0].ToString();
            txtnm.Text = dt1.Rows[0].ItemArray[1].ToString();
            txtfnm.Text = dt1.Rows[0].ItemArray[2].ToString();
            txtmnm.Text = dt1.Rows[0].ItemArray[3].ToString();
            txtaddrs.Text = dt1.Rows[0].ItemArray[4].ToString();
            string gen = dt1.Rows[0].ItemArray[5].ToString();
            try
            {
                if (gen.Equals("male"))
                {
                    rdbm.Checked = true; rdbf.Checked = false; rdbo.Checked = false;
                }
                else if (gen.Equals("female"))
                {
                    rdbf.Checked = true; rdbm.Checked = false; rdbo.Checked = false;
                }
                else if (gen.Equals("other"))
                {
                    rdbo.Checked = true; rdbm.Checked = false; rdbf.Checked = false;
                }
            }
            catch (Exception ee) { Response.Write(ee.ToString()); }
            txtdob.Text = dt1.Rows[0].ItemArray[6].ToString();
            txtage.Text = dt1.Rows[0].ItemArray[7].ToString();
            txtgotra.Text = dt1.Rows[0].ItemArray[8].ToString();
            txtkul.Text = dt1.Rows[0].ItemArray[9].ToString();
            txtcon.Text = dt1.Rows[0].ItemArray[10].ToString();
            txteid.Text = dt1.Rows[0].ItemArray[11].ToString();
            ddlcby.Text = dt1.Rows[0].ItemArray[12].ToString();
        }
        catch (Exception ee) { clr(); }
    }
    protected void btnHome_Click(object sender, EventArgs e)
    {
        if (Session["login"] == null)
        {
            Response.Redirect("~/frmPooja1.aspx");
        }
        else
        {
            Response.Redirect("~/frmPooja.aspx");
        }
    }
}