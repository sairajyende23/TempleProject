﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Clsconnection
/// </summary>
public class Clsconnection
{
    public string connection;
	public Clsconnection()
	{
		//
		// TODO: Add constructor logic here
		//
        connection=@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\HP\Documents\Visual Studio 2012\WebSites\KunkeshwarTempleManagement\App_Data\Temple.mdf;Integrated Security=True";
       // connection = "Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True";
	}
}