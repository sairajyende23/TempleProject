﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Sevakmaster : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt,dt1;
    int j,i, c, n;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from SevakMast", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    private void seeRecords()
    {
        txtSId.Text = dt.Rows[c].ItemArray[0].ToString();
        txtnm.Text = dt.Rows[c].ItemArray[1].ToString();
        txtaddrs.Text = dt.Rows[c].ItemArray[2].ToString();
        txtCno.Text = dt.Rows[c].ItemArray[3].ToString();
        txtEId.Text = dt.Rows[c].ItemArray[4].ToString();
        txtQuali.Text = dt.Rows[c].ItemArray[5].ToString();
        ddlDesig.Text = dt.Rows[c].ItemArray[6].ToString();
        ddlEby.Text= dt.Rows[c].ItemArray[7].ToString();        
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(SId) from SevakMast", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtSId.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtSId.Text = "1";
            dr.Close();
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No any Record..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecords();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecords();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
        cm = new SqlCommand("insert into SevakMast values(" + int.Parse(txtSId.Text) + ",'" + txtnm.Text + "','"+txtaddrs.Text+"',"+Int64.Parse(txtCno.Text)+",'"+txtEId.Text+"','"+txtQuali.Text+"','"+ddlDesig.SelectedItem+"','"+ddlEby.SelectedItem+"')", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record inserted successfully..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted Successfully..');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update SevakMast set SName='"+txtnm.Text+"',Address='"+txtaddrs.Text+"',ContactNo='"+Int64.Parse(txtCno.Text)+"',EmailId='"+txtEId.Text+"',Qualification='"+txtQuali.Text+"',Designation='"+ddlDesig.SelectedItem+"',EnterBy='"+ddlEby.SelectedItem+"' where SId="+int.Parse(txtSId.Text)+"", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from SevakMast where SId=" + int.Parse(txtSId.Text) + "",cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtSId.Text = "";
        txtnm.Text = "";
        txtaddrs.Text = "";
        txtCno.Text = "";
        txtQuali.Text = ""; txtEId.Text = ""; 
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt1.Clear();
            cm = new SqlCommand("select * from SevakMast where SId like( '" + int.Parse(txtSId.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt1.Load(dr);
            dr.Close();
            txtSId.Text = dt1.Rows[0].ItemArray[0].ToString();
            txtnm.Text = dt1.Rows[0].ItemArray[1].ToString();
            txtaddrs.Text = dt1.Rows[0].ItemArray[2].ToString();
            txtCno.Text = dt1.Rows[0].ItemArray[3].ToString();
            txtEId.Text = dt1.Rows[0].ItemArray[4].ToString();
            txtQuali.Text = dt1.Rows[0].ItemArray[5].ToString();
            ddlDesig.Text = dt1.Rows[0].ItemArray[6].ToString();
            ddlEby.Text = dt1.Rows[0].ItemArray[7].ToString();      
        }
        catch (Exception ee) { clr(); }
    }
}