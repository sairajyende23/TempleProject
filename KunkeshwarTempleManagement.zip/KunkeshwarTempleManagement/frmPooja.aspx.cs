﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Pooja : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm,cm1;
    SqlDataReader dr,dr1;
    DataTable dt,dt1,dt2;
    int c,i,j,n,n1,kk;
    string g,g1,k1;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        allRecords();
        lblToday.Text = DateTime.Now.ToShortDateString();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        if (Session["login"] == null)
        {
            btnUpdate.Visible = false;
            btnDelete.Visible = false;
            btnFst.Visible = false;
            btnNext.Visible = false;
            btnPre.Visible = false;
            btnLast.Visible = false;
        }
        if (rdbCheque.Checked == false)
        {
            txtCheque.Enabled = false;
        }
        else
        {
            txtCheque.Enabled = true;
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Pooja", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    private void seeRecord()
    {
        try
        {
            lblToday.Text = dt.Rows[c].ItemArray[0].ToString();
            txtPid.Text = dt.Rows[c].ItemArray[1].ToString();
            txtPDate.Text = dt.Rows[c].ItemArray[2].ToString();
            txtPtime.Text = dt.Rows[c].ItemArray[3].ToString();
            ddlBId.Text = dt.Rows[c].ItemArray[4].ToString();
            txtBnm.Text = dt.Rows[c].ItemArray[5].ToString();
            txtAddrs.Text = dt.Rows[c].ItemArray[6].ToString();
            txtCon.Text = dt.Rows[c].ItemArray[7].ToString();
            txtEid.Text = dt.Rows[c].ItemArray[8].ToString();
            g = dt.Rows[c].ItemArray[9].ToString();
            if (g.Equals("male"))
            {
                rdbm.Checked = true; rdbf.Checked = false; rdbo.Checked = false;
            }
            else if (g.Equals("female"))
            {
                rdbf.Checked = true; rdbm.Checked = false; rdbo.Checked = false;
            }
            else if (g.Equals("other"))
            {
                rdbo.Checked = true; rdbm.Checked = false; rdbf.Checked = false;
            }
            ddlPtype.Text = dt.Rows[c].ItemArray[10].ToString();
            txtExp.Text = dt.Rows[c].ItemArray[11].ToString();
            string type = dt.Rows[c].ItemArray[12].ToString();
            try
            {
                if (type.Equals("Cash"))
                {
                    rdbCash.Checked = true; rdbCheque.Checked = false; txtCheque.Enabled = false; rdbSwap.Checked = false; rdbEPayment.Checked = false;
                }
                else if (type.Equals("Cheque"))
                {
                    rdbCash.Checked = false; rdbCheque.Checked = true; txtCheque.Enabled = true; rdbSwap.Checked = false; rdbEPayment.Checked = false;
                }
                else if (type.Equals("Swap"))
                {
                    rdbCash.Checked = false; rdbCheque.Checked = false; txtCheque.Enabled = false; rdbSwap.Checked = true; rdbEPayment.Checked = false;
                }
                else if (type.Equals("E-Payment"))
                {
                    rdbCash.Checked = false; rdbCheque.Checked = false; txtCheque.Enabled = false; rdbSwap.Checked = false; rdbEPayment.Checked = true;
                }
            }
            catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "')</script>"); }
            txtCheque.Text = dt.Rows[c].ItemArray[13].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record !..');</script>"); }
        }
     protected void newId()
     {
        try
        {
            clr();
            cm = new SqlCommand("select max(PId) from Pooja", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtPid.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtPid.Text = "1";
            dr.Close();
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Further Record !..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            string s = null,t=null;
            if (rdbm.Checked == true)
            {
                s = "male";
            }
            else if (rdbf.Checked == true)
            {
                s = "female";
            }
            if (rdbCash.Checked == true)
            {
                t = "Cash";
            }
            else if (rdbCheque.Checked == true)
            {
                t = "Cheque";
            }
            else if (rdbSwap.Checked == true)
            {
                t = "Swap";
            }
            else if (rdbEPayment.Checked == true)
            {
                t = "E-Payment";
            }
            if (t == "Cheque")
            {
                cm = new SqlCommand("insert into Pooja values(@d1," + int.Parse(txtPid.Text) + ",@d2,'" + txtPtime.Text + "'," + int.Parse(ddlBId.Text) + ",'" + txtBnm.Text + "','" + txtAddrs.Text + "'," + Int64.Parse(txtCon.Text) + ",'" + txtEid.Text + "','" + s + "','" + ddlPtype.SelectedItem + "','" + Int64.Parse(txtExp.Text) + "','" + t + "','" + txtCheque.Text + "')", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtPDate.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record inserted successfully..');</script>");
                }
                clr();
            }
            else
            {
                cm = new SqlCommand("insert into Pooja values(@d1," + int.Parse(txtPid.Text) + ",@d2,'" + txtPtime.Text + "'," + int.Parse(ddlBId.Text) + ",'" + txtBnm.Text + "','" + txtAddrs.Text + "'," + Int64.Parse(txtCon.Text) + ",'" + txtEid.Text + "','" + s + "','" + ddlPtype.SelectedItem + "','" + Int64.Parse(txtExp.Text) + "','" + t + "','None')", cn);
                cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
                cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtPDate.Text).ToShortDateString();
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record inserted successfully..');</script>");
                }
                clr();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted Successfully..');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            string s = null, t = null; 
            if (rdbm.Checked == true)
            {
                s = "male";
            }
            else if (rdbf.Checked == true)
            {
                s = "female";
            }
            else if (rdbo.Checked == true)
            {
                s = "other";
            }
            if (rdbCash.Checked == true)
            {
                t = "Cash";
            }
            else if (rdbCheque.Checked == true)
            {
                t = "Cheque";
            }
            else if (rdbSwap.Checked == true)
            {
                t = "Swap";
            }
            else if (rdbEPayment.Checked == true)
            {
                t = "E-Payment";
            }
            cm = new SqlCommand("update Pooja set TDate=@d1,PDate=@d2,PTime='"+txtPtime.Text+"',bId=" + int.Parse(ddlBId.Text) + ",bName='" + txtBnm.Text + "',address='" + txtAddrs.Text + "',contactNo='" + Int64.Parse(txtCon.Text) + "',emailId='" + txtEid.Text + "',gender='" + s + "',PType='" + ddlPtype.SelectedItem + "',expences=" + Int64.Parse(txtExp.Text) + ",DType='"+t+"',ChequeNo='"+txtCheque.Text+"' where PId=" + int.Parse(txtPid.Text) + "", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(lblToday.Text).ToShortDateString();
            cm.Parameters.Add("@d2", SqlDbType.DateTime).Value = DateTime.Parse(txtPDate.Text).ToShortDateString();           
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from Pooja where PId="+int.Parse(txtPid.Text)+"", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtPid.Text = "";
        txtPDate.Text = "";
        txtBnm.Text = "";
        txtAddrs.Text = "";
        txtCon.Text = "";
        txtExp.Text = "";
        txtEid.Text = "";
        txtPtime.Text = "";
        txtCheque.Text = "";
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtPDate.Text = Calendar1.SelectedDate.ToShortDateString();
    }
    protected void btnshowBID_Click(object sender, EventArgs e)
    {
        enable();
        allRecords();
        select();
        select1();
        newId();       
    }
    protected void enable()
    {       
        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;
        btnAdd.Enabled = true;
        btnUpdate.Enabled = true;
        btnDelete.Enabled = true;
        btnClear.Enabled = true;
        btnDisplay.Enabled = true;
        btnShow.Enabled = true;
    }
    private void select()
    {
        ddlBId.Items.Clear();
        dt2.Clear();
        cm1 = new SqlCommand("select bId from BhaktMast",cn);
        dr1 = cm1.ExecuteReader();
        dt2.Load(dr1);
        dr1.Close();
        n1 = dt2.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlBId.Items.Add(dt2.Rows[i].ItemArray[0].ToString());
        }
    }
    protected void btnShow_Click(object sender, EventArgs e)
    {
        kk = int.Parse(ddlBId.SelectedItem.ToString());
        show(kk);
    }
    private void show(int kk)
    {
        cm1 = new SqlCommand("select * from BhaktMast where BId="+kk,cn);
        dr1 = cm1.ExecuteReader();
        if (dr1.Read())
        {
            txtBnm.Text = dr1[1].ToString();
            txtAddrs.Text = dr1[4].ToString();
            txtCon.Text = dr1[10].ToString();
            txtEid.Text = dr1[11].ToString();
           g1 = dr1[5].ToString();
            if (g1.Equals("male"))
            {
                rdbm.Checked = true; rdbf.Checked = false; rdbo.Checked = false;
            }
            else if (g1.Equals("female"))
            {
                rdbf.Checked = true; rdbm.Checked = false; rdbo.Checked = false;
            }
            else if (g1.Equals("other"))
            {
                rdbo.Checked = true; rdbm.Checked = false; rdbf.Checked = false;
            }
        }
        dr1.Close();       
    }
    private void select1()
    {
        ddlPtype.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select PName from PoojaMast",cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlPtype.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
        }
    }
    private void show1(string k1)
    {
        cm1 = new SqlCommand("select OtherDetails from PoojaMast where PName="+"'"+k1+"'", cn);
        dr1 = cm1.ExecuteReader();
        if (dr1.Read())
        {
            txtExp.Text = dr1[0].ToString();
        }
        dr1.Close();
    }
    protected void btnDisplay_Click(object sender, EventArgs e)
    {
        k1 = ddlPtype.SelectedItem.ToString();
        show1(k1);
    }
    protected void btnclickD_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/frmBhaktMaster.aspx");
    }
    protected void ImgCalender_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible == false)
        {
            Calendar1.Visible = true;
        }
        else if (Calendar1.Visible == true)
        {
            Calendar1.Visible = false;
        }
    }
}