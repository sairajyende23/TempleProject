﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmPayment : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm, cm1;
    SqlDataReader dr, dr1;
    DataTable dt, dt1, dt2;
    int c, i, j, n, n1,n2, kk;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }      
    }
    private void select1()
    {
        ddlId.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select SId from SevakMast", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlId.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
        }
    }

    protected void select2()
    {
        ddlDesig.Items.Clear();
        dt2.Clear();
        cm1 = new SqlCommand("select DName from Designation", cn);
        dr1 = cm1.ExecuteReader();
        dt2.Load(dr1);
        dr1.Close();
        n2 = dt2.Rows.Count - 1;
        for (i = 0; i <= n2; i++)
        {
            ddlDesig.Items.Add(dt2.Rows[i].ItemArray[0].ToString());
        }
    }
    protected void ImgCalender_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible == false)
        {
            Calendar1.Visible = true;
        }
        else if (Calendar1.Visible == true)
        {
            Calendar1.Visible = false;
        }
    }
         protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Payment", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
         private void seeRecord()
         {
             try
             {
                 ddlId.Text = dt.Rows[c].ItemArray[0].ToString();
                 txtnm.Text = dt.Rows[c].ItemArray[1].ToString();
                 ddlDesig.Text = dt.Rows[c].ItemArray[2].ToString();
                 txtDate.Text = dt.Rows[c].ItemArray[3].ToString();
                 txtPayment.Text = dt.Rows[c].ItemArray[4].ToString();
                 ddlEby.Text = dt.Rows[c].ItemArray[5].ToString();
             }
             catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record !..');</script>"); }
         }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Further Record !..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("insert into Payment values(" + int.Parse(ddlId.Text) + ",'" + txtnm.Text + "','" + ddlDesig.Text + "',@d1," + Int64.Parse(txtPayment.Text) + ",'" + ddlEby.Text + "')", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtDate.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record inserted successfully..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Inserted Successfully..');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update Payment set SName='" + txtnm.Text + "',Designation='" + ddlDesig.Text + "',TDate=@d1,Payment=" + Int64.Parse(txtPayment.Text) + ",EnterBy='" + ddlEby.Text + "' where PayId="+Int64.Parse(ddlId.Text)+"", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtDate.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from Payment where PayId=" + int.Parse(ddlId.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtDate.Text = "";
        txtnm.Text = "";
        txtPayment.Text = "";
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtDate.Text = Calendar1.SelectedDate.ToShortDateString();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        kk = int.Parse(ddlId.SelectedItem.ToString());
        show(kk);
    }
    private void show(int kk)
    {
        cm1 = new SqlCommand("select * from BhaktMast where BId=" + kk, cn);
        dr1 = cm1.ExecuteReader();
        if (dr1.Read())
        {
            txtnm.Text = dr1[1].ToString();
        }
        dr1.Close();
    }
    protected void btnshowBID_Click(object sender, EventArgs e)
    {
        select1(); select2();
    }
}