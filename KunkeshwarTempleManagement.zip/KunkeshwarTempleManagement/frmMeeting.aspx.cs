﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmMeeting : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm,cm1;
    SqlDataReader dr,dr1;
    DataTable dt,dt1,dt2;
    int c, i, j, n, n1; string a,b;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from Meeting", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void seeRecord()
    {
        try
        {
            txtMid.Text = dt.Rows[c].ItemArray[0].ToString();
            txtMDate.Text= dt.Rows[c].ItemArray[1].ToString();
            txtAgenda.Text = dt.Rows[c].ItemArray[2].ToString();
            ddlChairperson.Text=dt.Rows[c].ItemArray[3].ToString();
            txtResolution.Text = dt.Rows[c].ItemArray[4].ToString();
            ddlSactionedBy.Text = dt.Rows[c].ItemArray[5].ToString();
            txtVotes.Text = dt.Rows[c].ItemArray[6].ToString();
            txtNegVotes.Text = dt.Rows[c].ItemArray[7].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record !..');</script>"); }
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {
        enable();
        newId();
        select();
    }
    protected void enable()
    {
        txtMid.Enabled = true;
        txtAgenda.Enabled = true;
        btnAdd.Enabled = true;
        btnUpdate.Enabled = true;
        btnDelete.Enabled = true;
        btnClear.Enabled = true;
        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnLast.Enabled = true;
        txtMDate.Enabled = true;
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(MeetingId) from Meeting", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtMid.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtMid.Text = "1";
            dr.Close();
        }
    }
    protected void select()
    {
        ddlChairperson.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select Name from CommityMember", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlChairperson.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
            ddlSactionedBy.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Further Record !..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("insert into Meeting values("+int.Parse(txtMid.Text)+",@d1,'"+txtAgenda.Text+"','"+ddlChairperson.SelectedItem+"','"+txtResolution.Text+"','"+ddlSactionedBy.SelectedItem+"','"+Int64.Parse(txtVotes.Text)+"','"+Int64.Parse(txtNegVotes.Text)+"')", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtMDate.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Inserted successfully..');</script>");
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("update Meeting set MDate=@d1,Agenda='" + txtAgenda.Text + "',Chairperson='" + ddlChairperson.SelectedItem + "',Resolution='" + txtResolution.Text + "',SactionedBy='" + ddlSactionedBy.SelectedItem + "',Votes='" + Int64.Parse(txtVotes.Text) + "' NegativeVotes='" + Int64.Parse(txtNegVotes.Text) + "' where MeetingId=" + int.Parse(txtMid.Text) + "", cn);
            cm.Parameters.Add("@d1", SqlDbType.DateTime).Value = DateTime.Parse(txtMDate.Text).ToShortDateString();
            int z = cm.ExecuteNonQuery();
            if (z == 1) 
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from Meeting where MeetingId=" + int.Parse(txtMid.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtMid.Text = "";
        txtAgenda.Text = "";
        txtMDate.Text = "";
    }
    protected void btnAttendee_Click(object sender, EventArgs e)
    {
        Session["a"] = txtMid.Text;
        Session["b"] = txtMDate.Text;
        Response.Redirect("~/frmAttendeeMasterDetails.aspx");
    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        txtMDate.Text = @Calendar1.SelectedDate.Date.ToShortDateString();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt2.Clear();
            cm = new SqlCommand("select * from Meeting where MeetingId like( '" + int.Parse(txtMid.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt2.Load(dr);
            dr.Close();
            txtMid.Text = dt2.Rows[0].ItemArray[0].ToString();
            txtMDate.Text = dt2.Rows[0].ItemArray[1].ToString();
            txtAgenda.Text = dt2.Rows[0].ItemArray[2].ToString();
            ddlChairperson.Text = dt2.Rows[0].ItemArray[3].ToString();
            txtResolution.Text = dt2.Rows[0].ItemArray[4].ToString();
            ddlSactionedBy.Text = dt2.Rows[0].ItemArray[5].ToString();
            txtVotes.Text = dt2.Rows[0].ItemArray[6].ToString();
            txtNegVotes.Text = dt2.Rows[0].ItemArray[7].ToString();
        }
        catch (Exception ee) { clr(); }
    }
}