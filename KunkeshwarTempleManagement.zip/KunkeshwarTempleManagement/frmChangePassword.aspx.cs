﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class ChangePassword : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm;
    SqlDataReader dr;
    DataTable dt;
    int n;
    protected void Page_Load(object sender, EventArgs e)
    {
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        allRecords();
    }
    protected void allRecords()
    {
        dt.Clear();
        cm = new SqlCommand("select * from Login",cn);
        dr = cm.ExecuteReader();
        dt.Load(dr);
        dr.Close();
    }
    protected void btnChange_Click(object sender, EventArgs e)
    {
        if(txtNewPass.Text==txtConfirmPass.Text)
        {
           if(txtUName.Text==dt.Rows[0].ItemArray[1].ToString())
           {
               if (txtPass.Text == dt.Rows[0].ItemArray[2].ToString())
               {
                   cm = new SqlCommand("update Login set password='"+txtNewPass.Text+"'",cn);
                   n = cm.ExecuteNonQuery();
                   if (n == 1)
                   {
                       Response.Write("<script type='text/javascript'>alert('Password Change Successfully !...');</script>");
                       clr();
                   }
                   else
                   {
                       Response.Write("<script type='text/javascript'>alert('Password Not Change Successfully !...');</script>");
                   }
               }
               else
               {
                   Response.Write("<script type='text/javascript'>alert('Old Password Is Incorrect !...');</script>");
               }
           }
           else
           {
               Response.Write("<script type='text/javascript'>alert('User Name Does Not Match !...');</script>");
           }
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('Enter Correct Password !...');</script>");
        }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtUName.Text = "";
        txtPass.Text = "";
        txtNewPass.Text = "";
        txtConfirmPass.Text = "";
    }
}