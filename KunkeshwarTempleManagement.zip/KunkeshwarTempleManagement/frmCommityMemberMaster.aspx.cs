﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class frmCommityMasterMember : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm,cm1;
    SqlDataReader dr,dr1;
    DataTable dt,dt1,dt2;
    int c,n,j,n1,i;
    public string path1,path2,ss1=null,ss2=null,str1,str2;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
        if (ViewState["path1"] != null)
        {
            path1 = ViewState["path1"].ToString();
        }
        if (ViewState["path2"] != null)
        {
            path2 = ViewState["path2"].ToString();
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from CommityMember", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void seeRecord()
    {
        try
        {
            txtMId.Text = dt.Rows[c].ItemArray[0].ToString();
            txtAYear.Text = dt.Rows[c].ItemArray[1].ToString();
            txtnm.Text = dt.Rows[c].ItemArray[2].ToString();
            ddlDesig.Text = dt.Rows[c].ItemArray[3].ToString();
            txtAddrs.Text = dt.Rows[c].ItemArray[4].ToString();
            txtCon.Text = dt.Rows[c].ItemArray[5].ToString();
            txtEmailId.Text = dt.Rows[c].ItemArray[6].ToString();
            ImgPhoto.ImageUrl = dt.Rows[c].ItemArray[7].ToString();
            ImgSign.ImageUrl = dt.Rows[c].ItemArray[8].ToString();
            ddlCby.Text = dt.Rows[c].ItemArray[9].ToString();
            path1 = dt.Rows[c].ItemArray[7].ToString();
            path2 = dt.Rows[c].ItemArray[8].ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record !..');</script>"); }
    }
    protected void btnStart_Click(object sender, EventArgs e)
    {
        newId();
        select();
        enable();
    }
    protected void enable()
    {
        txtMId.Enabled = true;
        txtAddrs.Enabled = true;
        txtAYear.Enabled = true;
        txtCon.Enabled = true;
        txtEmailId.Enabled = true;
        txtnm.Enabled = true;
        btnAdd.Enabled = true;
        btnUpdate.Enabled = true;
        btnCancel.Enabled = true;
        btnDelete.Enabled = true;
        btnLast.Enabled = true;
        btnFst.Enabled = true;
        btnNext.Enabled = true;
        btnPre.Enabled = true;
        btnPhoto.Enabled = true;
        btnSign.Enabled = true;
        FileUploadPhoto.Enabled = true;
        FileUploadSign.Enabled = true;
        btnSearch.Enabled = true;
    }
    protected void select()
    {
        ddlDesig.Items.Clear();
        dt1.Clear();
        cm1 = new SqlCommand("select DName from Designation", cn);
        dr1 = cm1.ExecuteReader();
        dt1.Load(dr1);
        dr1.Close();
        n1 = dt1.Rows.Count - 1;
        for (i = 0; i <= n1; i++)
        {
            ddlDesig.Items.Add(dt1.Rows[i].ItemArray[0].ToString());
        }
    }
    protected void newId()
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(MemberId) from CommityMember", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtMId.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtMId.Text = "1";
            dr.Close(); 
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No Any Record !..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Previous Record !..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No Any Further Record !..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
                cm = new SqlCommand("insert into CommityMember values(" + int.Parse(txtMId.Text) + ",'" + txtAYear.Text + "','" + txtnm.Text + "','" + ddlDesig.SelectedItem + "','" + txtAddrs.Text + "'," + Int64.Parse(txtCon.Text) + ",'" + txtEmailId.Text + "','" + path1 + "','" + path2 + "','" + ddlCby.SelectedItem + "')", cn);
                int z = cm.ExecuteNonQuery();
                if (z == 1)
                {
                    Response.Write("<script type='text/javascript'>alert('Record Inserted successfully !..');</script>");
                    clr();
                }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert(" + ee.ToString() + ");</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {

            cm = new SqlCommand("update CommityMember set AYear='" + txtAYear.Text + "',Name='" + txtnm.Text + "',Designation='" + ddlDesig.SelectedItem + "',Address='" + txtAddrs.Text+ "',ContactNo=" + Int64.Parse(txtCon.Text) + ",EmailId='" + txtEmailId.Text + "',Photo='" + dt.Rows[c].ItemArray[7].ToString() + "',Sign='" + dt.Rows[c].ItemArray[8].ToString() + "',DataCBy='"+ddlCby.SelectedItem+"' where MemberId=" + int.Parse(txtMId.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated successfully !..');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from CommityMember where MemberId=" + int.Parse(txtMId.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully !..');</script>");
                clr();
            }
        }
        catch (Exception ee)
        {
            Response.Write("<script type='text/javascript'>alert('Record Not Deleted successfully !..');</script>");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtMId.Text = "";
        txtnm.Text = "";
        txtEmailId.Text = "";
        txtCon.Text = "";
        txtAYear.Text = "";
        txtAddrs.Text = ""; 
        ImgPhoto.ImageUrl = "";
        ImgSign.ImageUrl = "";
        path1 = ""; path2 = "";
    }
    protected void btnPhoto_Click(object sender, EventArgs e)
    {
        try
        {
            str1 = FileUploadPhoto.FileName;
            FileUploadPhoto.PostedFile.SaveAs(Server.MapPath(".") + "//Images//" + str1);
            ss1 = "~/Images/" + str1;
            ImgPhoto.ImageUrl = ss1;
            path1 = "~//Images//" + str1.ToString();
            ViewState["path1"] = path1.ToString();
            
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Image Not selected !..');</script>"); }
    }
    protected void btnSign_Click(object sender, EventArgs e)
    {
        try
        {
            str2 = FileUploadSign.FileName;
            FileUploadSign.PostedFile.SaveAs(Server.MapPath(".") + "//Images//" + str2);
            ss2 = "~/Images/" + str2;
            ImgSign.ImageUrl = ss2;
            path2 = "~//Images//" + str2.ToString();
            ViewState["path2"] = path2.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Image Not selected !..');</script>"); }
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt2.Clear();
            cm = new SqlCommand("select * from CommityMember where MemberId like( '" + int.Parse(txtMId.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt2.Load(dr);
            dr.Close();
            txtMId.Text = dt2.Rows[0].ItemArray[0].ToString();
            txtAYear.Text = dt2.Rows[0].ItemArray[1].ToString();
            txtnm.Text = dt2.Rows[0].ItemArray[2].ToString();
            ddlDesig.Text = dt2.Rows[0].ItemArray[3].ToString();
            txtAddrs.Text = dt2.Rows[0].ItemArray[4].ToString();
            txtCon.Text = dt2.Rows[0].ItemArray[5].ToString();
            txtEmailId.Text = dt2.Rows[0].ItemArray[6].ToString();
            ImgPhoto.ImageUrl = dt2.Rows[0].ItemArray[7].ToString();
            ImgSign.ImageUrl = dt2.Rows[0].ItemArray[8].ToString();
            ddlCby.Text = dt2.Rows[0].ItemArray[9].ToString();
            path1 = dt2.Rows[0].ItemArray[7].ToString();
            path2 = dt2.Rows[0].ItemArray[8].ToString();
        }
        catch (Exception ee) { clr(); }
    }
}