﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class RoomMaster : System.Web.UI.Page
{
    SqlConnection cn;
    SqlCommand cm, cm1;
    SqlDataReader dr, dr1;
    DataTable dt, dt1,dt2;
    int k, j, i, c, n, n1, b,kk;
    string Rstatus;
    protected void Page_Load(object sender, EventArgs e)
    {
        //cn = new SqlConnection("Data Source=(LocalDB)\\v11.0;AttachDbFilename=C:\\Users\\HP\\Documents\\Visual Studio 2012\\WebSites\\TempleManagement\\App_Data\\Temple.mdf;Integrated Security=True");
        Clsconnection cc = new Clsconnection();
        cn = new SqlConnection(cc.connection);
        cn.Open();
        dt = new DataTable();
        dt1 = new DataTable();
        dt2 = new DataTable();
        allRecords();
        if (ViewState["c"] != null)
        {
            c = int.Parse(ViewState["c"].ToString());
        }
    }
    protected void allRecords()
    {
        try
        {
            dt.Clear();
            cm = new SqlCommand("select * from RoomMaster", cn);
            dr = cm.ExecuteReader();
            dt.Load(dr);
            dr.Close();
            n = dt.Rows.Count - 1;
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('" + ee.ToString() + "');</script>"); }
    }
    protected void seeRecord()
    {
        txtRoom.Text=dt.Rows[c].ItemArray[0].ToString();
        ddlRType.Text=dt.Rows[c].ItemArray[1].ToString();
        txtCoats.Text=dt.Rows[c].ItemArray[2].ToString();
        txtRent.Text=dt.Rows[c].ItemArray[3].ToString();
        string s=dt.Rows[c].ItemArray[4].ToString();
        if (s == "Booked")
        {
            rdbBooked.Checked = true; rdbReleased.Checked = false;
        }
        else if(s =="Released")
        {
            rdbReleased.Checked = true; rdbBooked.Checked = false;
        }
        ddlCby.Text = dt.Rows[c].ItemArray[5].ToString();
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        try
        {
            clr();
            cm = new SqlCommand("select max(RoomNo) from RoomMaster", cn);
            dr = cm.ExecuteReader();
            if (dr.Read())
            {
                j = int.Parse(dr[0].ToString()) + 1;
                txtRoom.Text = j.ToString();
            }
            dr.Close();
        }
        catch (Exception ee)
        {
            txtRoom.Text = "1";
            dr.Close();
        }
    }
    protected void btnFst_Click(object sender, EventArgs e)
    {
        try
        {
            c = 0;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('No any Record..');</script>"); }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        if (c < n)
        {
            c++;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Further Record..');</script>");
        }
    }
    protected void btnPre_Click(object sender, EventArgs e)
    {
        if (c > 0)
        {
            c--;
            seeRecord();
            ViewState["c"] = c.ToString();
        }
        else
        {
            Response.Write("<script type='text/javascript'>alert('No any Previous Record..');</script>");
        }
    }
    protected void btnLast_Click(object sender, EventArgs e)
    {
        c = n;
        seeRecord();
        ViewState["c"] = c.ToString();
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            if (rdbBooked.Checked == true)
            {
                Rstatus = "Booked";
            }
            else if (rdbReleased.Checked == true)
            {
                Rstatus = "Released";
            }
            cm = new SqlCommand("insert into RoomMaster values(" + int.Parse(txtRoom.Text) + ",'" + ddlRType.SelectedItem + "','" + Int64.Parse(txtCoats.Text) + "','" + Int64.Parse(txtRent.Text) + "','" + Rstatus + "','" + ddlCby.SelectedItem + "')", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record inserted successfully..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record Not Updated Successfully..');</script>"); }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            if (rdbBooked.Checked == true)
            {
                Rstatus = "Booked";
            }
            else if (rdbReleased.Checked == true)
            {
                Rstatus = "Released";
            }
            cm = new SqlCommand("update RoomMaster set Type='" + ddlRType.SelectedItem + "',NoOfCoats='" + Int64.Parse(txtCoats.Text) + "',Rent='" + Int64.Parse(txtRent.Text) + "',status='" + Rstatus + "',EnterBy='" + ddlCby.SelectedItem + "' where RoomNo=" + int.Parse(txtRoom.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Updated successfully..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('"+ee.ToString()+"');</script>"); }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            cm = new SqlCommand("delete from RoomMaster where RoomNo=" + int.Parse(txtRoom.Text) + "", cn);
            int z = cm.ExecuteNonQuery();
            if (z == 1)
            {
                Response.Write("<script type='text/javascript'>alert('Record Deleted successfully..');</script>");
            }
            clr();
        }
        catch (Exception ee) { Response.Write("<script type='text/javascript'>alert('Record not Deleted successfully..');</script>"); }
    }
    protected void btnClear_Click(object sender, EventArgs e)
    {
        clr();
    }
    protected void clr()
    {
        txtRoom.Text = "";
        txtRent.Text = "";
        txtCoats.Text = "";
        rdbBooked.Checked = false;
        rdbReleased.Checked = false;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        try
        {
            dt2.Clear();
            cm = new SqlCommand("select * from RoomMaster where RoomNo like( '" + int.Parse(txtRoom.Text) + "%')", cn);
            dr = cm.ExecuteReader();
            dt2.Load(dr);
            dr.Close();
            txtRoom.Text = dt2.Rows[0].ItemArray[0].ToString();
            ddlRType.Text = dt2.Rows[0].ItemArray[1].ToString();
            txtCoats.Text = dt2.Rows[0].ItemArray[2].ToString();
            txtRent.Text = dt2.Rows[0].ItemArray[3].ToString();
            string s = dt2.Rows[0].ItemArray[4].ToString();
            if (s == "Booked")
            {
                rdbBooked.Checked = true; rdbReleased.Checked = false;
            }
            else if (s == "Released")
            {
                rdbReleased.Checked = true; rdbBooked.Checked = false;
            }
            ddlCby.Text = dt2.Rows[0].ItemArray[5].ToString();
        }
        catch (Exception ee) { clr(); }
    }
}